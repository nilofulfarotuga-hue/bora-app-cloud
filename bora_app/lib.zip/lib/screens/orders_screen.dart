import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../stores/order_store.dart';
import '../models/order_model.dart';
import 'order_details_screen.dart';


class OrdersScreen extends StatelessWidget {
  const OrdersScreen({super.key});

  @override
  Widget build(BuildContext context) {

    final store = context.watch<OrderStore>();

    final orders = store.orders;

    return Scaffold(

      appBar: AppBar(
        title: const Text("Pedidos"),
      ),

      body: orders.isEmpty
          ? const Center(child: Text("Nenhum pedido"))
          : ListView.builder(

              itemCount: orders.length,

              itemBuilder: (context, index) {

                final order = orders[index];

                                                return ListTile(
                  title: Text("Pedido €${order.total.toStringAsFixed(2)}"),
                  subtitle: Text(order.status.label),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => OrderDetailsScreen(order: order),
                      ),
                    );
                  },
                );



              },

            ),

    );
  }
}