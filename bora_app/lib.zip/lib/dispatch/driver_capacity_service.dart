import 'package:latlong2/latlong.dart';

import '../models/driver_model.dart';
import '../models/order_model.dart';

class DriverCapacityService {
  DriverCapacityService({
    Distance? distance,
    double partnerRadiusMeters = 800,
    int partnerMaxOrders = 2,
    int nonPartnerMaxOrders = 3,
  })  : _distance = distance ?? const Distance(),
        _partnerRadiusKm = partnerRadiusMeters / 1000,
        _partnerMaxOrders = partnerMaxOrders,
        _nonPartnerMaxOrders = nonPartnerMaxOrders;

  final Distance _distance;
  final double _partnerRadiusKm;
  final int _partnerMaxOrders;
  final int _nonPartnerMaxOrders;

  bool canAssignOrder(DriverModel driver, OrderModel order) {
    if (!driver.isOnline) return false;

    final assignments = driver.activeAssignments;
    if (assignments.isEmpty) {
      // No batching restrictions when the driver is free. Logistics orders are
      // allowed because there are no active assignments.
      return true;
    }

    final hasLogisticsAssignment =
        assignments.any((info) => _isLogistics(info.serviceType));
    final isLogisticsOrder = _isLogistics(order.serviceType);

    if (hasLogisticsAssignment) {
      // Drivers carrying logistics orders cannot take additional orders.
      return false;
    }

    if (isLogisticsOrder) {
      // Logistics orders can only be taken when the driver is currently free.
      return assignments.isEmpty;
    }

    if (order.isPartnerOrder) {
      return _canAcceptPartnerOrder(assignments, order);
    }

    return _canAcceptNonPartnerOrder(assignments, order);
  }

  bool shouldPrioritize(OrderModel order, DriverModel driver) {
    if (order.isPartnerOrder) return false;
    final vendorName = order.vendorName;
    if (vendorName == null) return false;

    return driver.activeAssignments.any(
      (info) =>
          !info.isPartnerOrder &&
          info.vendorName != null &&
          info.vendorName == vendorName,
    );
  }

  bool _canAcceptPartnerOrder(
    List<DriverAssignmentInfo> assignments,
    OrderModel order,
  ) {
    final partnerAssignments =
        assignments.where((info) => info.isPartnerOrder).toList();

    if (partnerAssignments.length >= _partnerMaxOrders) {
      return false;
    }

    if (partnerAssignments.isEmpty) {
      return true;
    }

    final vendorName = order.vendorName;
    if (vendorName != null) {
      final hasSameVendor = partnerAssignments.any(
        (info) => info.vendorName != null && info.vendorName == vendorName,
      );
      if (hasSameVendor) {
        return true;
      }
    }

    final pickup = order.pickupLocation;
    if (pickup == null) {
      // Without pickup coordinates we require matching vendor.
      return false;
    }

    final isWithinRadius = partnerAssignments.any((info) {
      final existingPickup = info.pickupLocation;
      if (existingPickup == null) return false;
      final distanceKm =
          _distance.as(LengthUnit.Kilometer, existingPickup, pickup);
      return distanceKm <= _partnerRadiusKm;
    });

    return isWithinRadius;
  }

  bool _canAcceptNonPartnerOrder(
    List<DriverAssignmentInfo> assignments,
    OrderModel order,
  ) {
    final nonPartnerAssignments =
        assignments.where((info) => !info.isPartnerOrder).toList();
    if (nonPartnerAssignments.isEmpty) {
      return true;
    }

    final vendorName = order.vendorName;
    if (vendorName == null) {
      // Cannot batch non-partner orders without knowing the vendor.
      return false;
    }

    final hasDifferentVendor = nonPartnerAssignments.any(
      (info) => info.vendorName != null && info.vendorName != vendorName,
    );

    if (hasDifferentVendor) {
      return false;
    }

    return nonPartnerAssignments.length < _nonPartnerMaxOrders;
  }

  bool _isLogistics(OrderServiceType type) {
    return type == OrderServiceType.carryGroceries ||
        type == OrderServiceType.sendPackage;
  }
}
