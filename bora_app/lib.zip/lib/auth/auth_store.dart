import 'package:flutter/material.dart';

import '../models/driver_model.dart';
import '../models/restaurant_model.dart';

enum AuthRole { client, driver, partner }

class ClientAccount {
  const ClientAccount({
    required this.name,
    required this.email,
    required this.phone,
    required this.password,
  });

  final String name;
  final String email;
  final String phone;
  final String password;
}

class DriverAccount {
  const DriverAccount({
    required this.name,
    required this.phone,
    required this.vehicleType,
    required this.licensePlate,
    required this.password,
  });

  final String name;
  final String phone;
  final VehicleType vehicleType;
  final String licensePlate;
  final String password;
}

class PartnerAccount {
  const PartnerAccount({
    required this.restaurantName,
    required this.address,
    required this.phone,
    required this.email,
    required this.password,
    required this.photoUrl,
    required this.cuisineType,
  });

  final String restaurantName;
  final String address;
  final String phone;
  final String email;
  final String password;
  final String photoUrl;
  final String cuisineType;
}

class AuthStore extends ChangeNotifier {
  AuthStore() {
    _clientsByEmail['cliente@bora.app'] = const ClientAccount(
      name: 'Cliente Demo',
      email: 'cliente@bora.app',
      phone: '910000001',
      password: '123456',
    );

    _driversByPhone['910000000'] = const DriverAccount(
      name: 'Estafeta Demo',
      phone: '910000000',
      vehicleType: VehicleType.car,
      licensePlate: 'AB-12-CD',
      password: '123456',
    );
  }

  final Map<String, ClientAccount> _clientsByEmail = {};
  final Map<String, DriverAccount> _driversByPhone = {};
  final Map<String, PartnerAccount> _partnersByEmail = {};

  ClientAccount? _currentClient;
  DriverAccount? _currentDriver;
  PartnerAccount? _currentPartner;

  /// 🔹 Restaurante parceiro salvo em memória
  RestaurantModel? _partnerRestaurant;

  RestaurantModel? get partnerRestaurant => _partnerRestaurant;

  void setPartnerRestaurant(RestaurantModel restaurant) {
    _partnerRestaurant = restaurant;
    notifyListeners();
  }

  bool get isLogged =>
      _currentClient != null || _currentDriver != null || _currentPartner != null;

  AuthRole? get role {
    if (_currentClient != null) return AuthRole.client;
    if (_currentDriver != null) return AuthRole.driver;
    if (_currentPartner != null) return AuthRole.partner;
    return null;
  }

  String? get displayName =>
      _currentClient?.name ??
      _currentDriver?.name ??
      _currentPartner?.restaurantName;

  ClientAccount? get currentClient => _currentClient;

  DriverAccount? get currentDriver => _currentDriver;

  PartnerAccount? get currentPartner => _currentPartner;

  bool get hasClientAccounts => _clientsByEmail.isNotEmpty;

  bool get hasDriverAccounts => _driversByPhone.isNotEmpty;

  bool get hasPartnerAccounts => _partnersByEmail.isNotEmpty;

    String? registerClient({
    required String name,
    required String email,
    required String phone,
    required String password,
  }) {
    final normalizedEmail = email.trim().toLowerCase();
    if (normalizedEmail.isEmpty || password.isEmpty) {
      return 'Preencha todos os campos obrigatórios.';
    }
    if (_clientsByEmail.containsKey(normalizedEmail)) {
      return 'Já existe uma conta com este e-mail.';
    }

    final account = ClientAccount(
      name: name.trim(),
      email: normalizedEmail,
      phone: phone.trim(),
      password: password,
    );

    _clientsByEmail[normalizedEmail] = account;
    _currentClient = account;
    _currentDriver = null;
    _currentPartner = null;

    notifyListeners();
    return null;
  }

  String? registerDriver({
    required String name,
    required String phone,
    required VehicleType vehicleType,
    required String licensePlate,
    required String password,
  }) {
    final normalizedPhone = phone.trim();
    if (normalizedPhone.isEmpty || password.isEmpty) {
      return 'Preencha todos os campos obrigatórios.';
    }
    if (_driversByPhone.containsKey(normalizedPhone)) {
      return 'Já existe um estafeta registado com este telemóvel.';
    }

    final account = DriverAccount(
      name: name.trim(),
      phone: normalizedPhone,
      vehicleType: vehicleType,
      licensePlate: licensePlate.trim(),
      password: password,
    );

    _driversByPhone[normalizedPhone] = account;
    _currentDriver = account;
    _currentClient = null;
    _currentPartner = null;

    notifyListeners();
    return null;
  }

  String? registerPartner({
    required String restaurantName,
    required String address,
    required String phone,
    required String email,
    required String password,
    required String photoUrl,
    required String cuisineType,
  }) {
    final normalizedEmail = email.trim().toLowerCase();
    if (restaurantName.trim().isEmpty ||
        normalizedEmail.isEmpty ||
        password.isEmpty) {
      return 'Preencha todos os campos obrigatórios.';
    }

    if (_partnersByEmail.containsKey(normalizedEmail)) {
      return 'Já existe um parceiro registado com este email.';
    }

    final partner = PartnerAccount(
      restaurantName: restaurantName.trim(),
      address: address.trim(),
      phone: phone.trim(),
      email: normalizedEmail,
      password: password,
      photoUrl: photoUrl.trim(),
      cuisineType: cuisineType.trim(),
    );

    _partnersByEmail[normalizedEmail] = partner;

    _currentPartner = partner;
    _currentClient = null;
    _currentDriver = null;

    notifyListeners();
    return null;
  }

  bool loginClient(String email, String password) {
    final account = _clientsByEmail[email.trim().toLowerCase()];
    if (account == null || account.password != password) {
      return false;
    }

    _currentClient = account;
    _currentDriver = null;
    _currentPartner = null;

    notifyListeners();
    return true;
  }

  bool loginDriver(String phone, String password) {
    final account = _driversByPhone[phone.trim()];
    if (account == null || account.password != password) {
      return false;
    }

    _currentDriver = account;
    _currentClient = null;
    _currentPartner = null;

    notifyListeners();
    return true;
  }

  bool loginPartner(String email, String password) {
    final account = _partnersByEmail[email.trim().toLowerCase()];
    if (account == null || account.password != password) {
      return false;
    }

    _currentPartner = account;
    _currentClient = null;
    _currentDriver = null;

    notifyListeners();
    return true;
  }

  PartnerAccount? partnerAccountByEmail(String email) {
    return _partnersByEmail[email.trim().toLowerCase()];
  }

  DriverAccount? driverAccountByPhone(String phone) {
    return _driversByPhone[phone.trim()];
  }

  void logout() {
    _currentClient = null;
    _currentDriver = null;
    _currentPartner = null;
    _partnerRestaurant = null;

    notifyListeners();
  }
}