export 'order_service_type.dart';

import 'package:latlong2/latlong.dart';
import 'package:uuid/uuid.dart';

import 'cart_item.dart';
import 'order_service_type.dart';

const double _platformCommissionRate = 0.20;
const double _restaurantEarningsRate = 1 - _platformCommissionRate;

enum OrderStatus {
  created,
  preparing,
  callingDriver,
  driverAccepted,
  pickedUp,
  onTheWay,
  delivered,
  rejected,
}

enum OrderType {
  partnerRestaurant,
  nonPartnerPurchase,
}

enum PaymentMethod {
  card,
  mbway,
  cash,
}

class OrderModel {
  final String id;
  DateTime? driverOfferExpiresAt;
  final OrderServiceType serviceType;
  final double subtotal;
  final double deliveryFee;
  final double serviceFee;
  final double platformCommission;
  final double driverEarnings;
  final double distanceKm;
  final double total;
  final LatLng? pickupLocation;
  final LatLng? destination;
  final String? vendorName;
  final String? pickupAddress;
  final String? pickupStreet;
  final String? pickupCity;
  final String? pickupPostalCode;
  final String? dropoffAddress;
  final String? dropoffStreet;
  final String? dropoffCity;
  final String? dropoffPostalCode;
  final String? customerNotes;
  final bool isPartnerStore;
  final bool apartmentDelivery;
  final OrderType orderType;
  final PaymentMethod paymentMethod;
  final DateTime createdAt;
  final String? clientPhone;
  final String? customerName;
  final List<CartItem> items;

  String? assignedDriverId;
  String? currentDriverOfferId;
  String? driverPhone;
  final List<String> driverOfferHistory;
  bool pickupWarningIssued;

  OrderStatus status;

  OrderModel({
    required this.total,
    required this.serviceType,
    this.subtotal = 0,
    this.deliveryFee = 0,
    this.serviceFee = 0,
    this.platformCommission = 0,
    this.driverEarnings = 0,
    this.distanceKm = 0,
    this.pickupLocation,
    this.destination,
    this.vendorName,
    this.pickupAddress,
    this.pickupStreet,
    this.pickupCity,
    this.pickupPostalCode,
    this.dropoffAddress,
    this.dropoffStreet,
    this.dropoffCity,
    this.dropoffPostalCode,
    this.customerNotes,
    this.isPartnerStore = false,
    this.apartmentDelivery = false,
    this.orderType = OrderType.nonPartnerPurchase,
    this.paymentMethod = PaymentMethod.cash,
    this.status = OrderStatus.created,
    String? id,
    DateTime? createdAt,
    this.clientPhone,
    this.customerName,
    List<CartItem>? items,
    this.assignedDriverId,
    this.currentDriverOfferId,
    this.driverPhone,
    List<String>? driverOfferHistory,
    this.pickupWarningIssued = false,
  })  : items = List<CartItem>.unmodifiable(items ?? const <CartItem>[]),
        id = id ?? const Uuid().v4(),
        createdAt = createdAt ?? DateTime.now(),
        driverOfferHistory = driverOfferHistory ?? <String>[];

  factory OrderModel.fromSupabase(Map<String, dynamic> data) {
    return OrderModel(
      id: data['id'],
      total: (data['price'] ?? 0).toDouble(),
      serviceType: OrderServiceType.storeShopping,
      status: OrderStatus.created,
      pickupAddress: data['pickup_address'] ?? '',
      dropoffAddress: data['dropoff_address'] ?? '',
      createdAt: DateTime.parse(data['created_at']),
    );
  }
}

extension OrderModelX on OrderModel {
  bool get isPartnerOrder => orderType == OrderType.partnerRestaurant;
}

extension OrderFinancials on OrderModel {
  double get platformCommissionAmount {
    if (platformCommission > 0) {
      return platformCommission;
    }
    return total * _platformCommissionRate;
  }

  double get restaurantEarningsAmount => total - platformCommissionAmount;
}

extension OrderStatusLabel on OrderStatus {
  String get label {
    switch (this) {
      case OrderStatus.created:
        return "Pedido criado";
      case OrderStatus.preparing:
        return "Restaurante preparando";
      case OrderStatus.callingDriver:
        return "Aguardando estafeta";
      case OrderStatus.driverAccepted:
        return "Estafeta a caminho";
      case OrderStatus.pickedUp:
        return "Encomenda recolhida";
      case OrderStatus.onTheWay:
        return "Em entrega";
      case OrderStatus.delivered:
        return "Entregue";
      case OrderStatus.rejected:
        return "Pedido rejeitado";
    }
  }
}

extension PaymentMethodLabel on PaymentMethod {
  String get label {
    switch (this) {
      case PaymentMethod.card:
        return "Cartão";
      case PaymentMethod.mbway:
        return "MBWay";
      case PaymentMethod.cash:
        return "Dinheiro";
    }
  }
}
