import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/order_model.dart';
import '../models/partner_product.dart';
import '../models/restaurant_model.dart';

class RestaurantStore extends ChangeNotifier {
  final supabase = Supabase.instance.client;
  static final List<RestaurantModel> _partnerRestaurants = [];

  RestaurantStore()
      : _restaurants = [
          const RestaurantModel(
            id: 'rest-mcdonalds',
            name: "McDonald's",
            phone: '210000001',
            address: 'Av. Fontes Pereira de Melo 5, Lisboa',
            email: 'contato@mcdonalds.pt',
            photoUrl:
                'https://via.placeholder.com/240x140.png?text=McDonald%27s',
            cuisineType: 'Fast Food',
            isPartner: false,
            category: BusinessCategory.restaurant,
          ),
          const RestaurantModel(
            id: 'rest-burger-king',
            name: 'Burger King',
            phone: '210000002',
            address: 'R. Joaquim António de Aguiar 16, Lisboa',
            email: 'contato@burgerking.pt',
            photoUrl:
                'https://via.placeholder.com/240x140.png?text=Burger+King',
            cuisineType: 'Hambúrgueres',
            isPartner: false,
            category: BusinessCategory.restaurant,
          ),
          const RestaurantModel(
            id: 'rest-pizzahut',
            name: 'Pizza Hut',
            phone: '210000003',
            address: 'Av. de Berna 12, Lisboa',
            email: 'contato@pizzahut.pt',
            photoUrl: 'https://via.placeholder.com/240x140.png?text=Pizza+Hut',
            cuisineType: 'Pizzaria',
            isPartner: true,
            category: BusinessCategory.restaurant,
          ),
          const RestaurantModel(
            id: 'rest-kfc',
            name: 'KFC',
            phone: '210000004',
            address: 'Praça Martim Moniz 2, Lisboa',
            email: 'contato@kfc.pt',
            photoUrl: 'https://via.placeholder.com/240x140.png?text=KFC',
            cuisineType: 'Frango Frito',
            isPartner: true,
            category: BusinessCategory.restaurant,
          ),
          const RestaurantModel(
            id: 'market-mini-mercado',
            name: 'Mini Mercado Lisboa',
            phone: '210000101',
            address: 'Rua da Madalena 220, Lisboa',
            email: 'contacto@minimercadolx.pt',
            photoUrl:
                'https://via.placeholder.com/240x140.png?text=Mini+Mercado',
            cuisineType: 'Mercearia',
            isPartner: true,
            category: BusinessCategory.supermarket,
          ),
          const RestaurantModel(
            id: 'market-super-bairro',
            name: 'Super Bairro Market',
            phone: '210000102',
            address: 'Rua Marquês Sá da Bandeira 88, Lisboa',
            email: 'contacto@superbairro.pt',
            photoUrl:
                'https://via.placeholder.com/240x140.png?text=Supermercado',
            cuisineType: 'Supermercado',
            isPartner: true,
            category: BusinessCategory.supermarket,
          ),
          const RestaurantModel(
            id: 'store-lisboa-shop',
            name: 'Lisboa Lifestyle Store',
            phone: '210000201',
            address: 'Rua Augusta 150, Lisboa',
            email: 'contato@lisboastore.pt',
            photoUrl: 'https://via.placeholder.com/240x140.png?text=Loja',
            cuisineType: 'Vestuário e presentes',
            isPartner: false,
            category: BusinessCategory.store,
          ),
          const RestaurantModel(
            id: 'pharmacy-central',
            name: 'Farmácia Central',
            phone: '210000301',
            address: 'Rossio 28, Lisboa',
            email: 'atendimento@farmaciacentral.pt',
            photoUrl: 'https://via.placeholder.com/240x140.png?text=Farmacia',
            cuisineType: 'Produtos de saúde',
            isPartner: false,
            category: BusinessCategory.pharmacy,
          ),
        ];

  final List<RestaurantModel> _restaurants;
  final Map<String, List<PartnerProduct>> _productsByRestaurant = {
    'rest-mcdonalds': [
      const PartnerProduct(
        id: 'rest-mcdonalds-prod-1',
        name: 'Big Mac',
        description:
            'Clássico hambúrguer com carne, alface, queijo e molho especial.',
        price: 6.90,
        photoUrl: 'https://via.placeholder.com/240x140.png?text=Big+Mac',
        isAvailable: true,
      ),
      const PartnerProduct(
        id: 'rest-mcdonalds-prod-2',
        name: 'McNuggets 10 unidades',
        description: 'Deliciosos pedaços de frango empanado.',
        price: 5.50,
        photoUrl: 'https://via.placeholder.com/240x140.png?text=McNuggets',
        isAvailable: true,
      ),
    ],
    'rest-burger-king': [
      const PartnerProduct(
        id: 'rest-burger-king-prod-1',
        name: 'Whopper',
        description: 'Hambúrguer com carne grelhada, tomate, alface e molho.',
        price: 7.40,
        photoUrl: 'https://via.placeholder.com/240x140.png?text=Whopper',
        isAvailable: true,
      ),
    ],
    'rest-pizzahut': [
      const PartnerProduct(
        id: 'rest-pizzahut-prod-1',
        name: 'Pizza Pepperoni Lovers',
        description: 'Massa pan com molho de tomate, queijo e muito pepperoni.',
        price: 11.90,
        photoUrl:
            'https://via.placeholder.com/240x140.png?text=Pepperoni+Pizza',
        isAvailable: true,
      ),
    ],
    'market-mini-mercado': [
      const PartnerProduct(
        id: 'market-mini-mercado-prod-1',
        name: 'Banana (1kg)',
        description: 'Fruta fresca selecionada pelo parceiro.',
        price: 1.80,
        photoUrl: 'https://via.placeholder.com/240x140.png?text=Banana',
        isAvailable: true,
      ),
      const PartnerProduct(
        id: 'market-mini-mercado-prod-2',
        name: 'Leite 1L',
        description: 'Leite meio gordo 1 litro.',
        price: 1.10,
        photoUrl: 'https://via.placeholder.com/240x140.png?text=Leite',
        isAvailable: true,
      ),
      const PartnerProduct(
        id: 'market-mini-mercado-prod-3',
        name: 'Ovos 12 unidades',
        description: 'Ovos classe M frescos.',
        price: 2.20,
        photoUrl: 'https://via.placeholder.com/240x140.png?text=Ovos',
        isAvailable: true,
      ),
    ],
    'market-super-bairro': [
      const PartnerProduct(
        id: 'market-super-bairro-prod-1',
        name: 'Maçã Gala (1kg)',
        description: 'Maçãs frescas selecionadas.',
        price: 2.10,
        photoUrl: 'https://via.placeholder.com/240x140.png?text=Maca',
        isAvailable: true,
      ),
      const PartnerProduct(
        id: 'market-super-bairro-prod-2',
        name: 'Pão fresco',
        description: 'Pão tradicional cozido no dia.',
        price: 1.50,
        photoUrl: 'https://via.placeholder.com/240x140.png?text=Pao',
        isAvailable: true,
      ),
      const PartnerProduct(
        id: 'market-super-bairro-prod-3',
        name: 'Azeite virgem extra 0,5L',
        description: 'Azeite português premium.',
        price: 4.90,
        photoUrl: 'https://via.placeholder.com/240x140.png?text=Azeite',
        isAvailable: true,
      ),
    ],
    'store-lisboa-shop': [
      const PartnerProduct(
        id: 'store-lisboa-shop-prod-1',
        name: 'Caneca Lisboa',
        description: 'Caneca temática com ícones da cidade.',
        price: 8.90,
        photoUrl: 'https://via.placeholder.com/240x140.png?text=Caneca',
        isAvailable: true,
      ),
      const PartnerProduct(
        id: 'store-lisboa-shop-prod-2',
        name: 'Tote bag tram 28',
        description: 'Saco reutilizável com ilustração do elétrico 28.',
        price: 6.50,
        photoUrl: 'https://via.placeholder.com/240x140.png?text=Tote',
        isAvailable: true,
      ),
    ],
    'pharmacy-central': [
      const PartnerProduct(
        id: 'pharmacy-central-prod-1',
        name: 'Paracetamol 500mg',
        description: 'Embalagem com 20 comprimidos.',
        price: 3.50,
        photoUrl: 'https://via.placeholder.com/240x140.png?text=Paracetamol',
        isAvailable: true,
      ),
      const PartnerProduct(
        id: 'pharmacy-central-prod-2',
        name: 'Vitamina C 1g',
        description: 'Suplemento alimentar efervescente.',
        price: 6.90,
        photoUrl: 'https://via.placeholder.com/240x140.png?text=Vitamina+C',
        isAvailable: true,
      ),
      const PartnerProduct(
        id: 'pharmacy-central-prod-3',
        name: 'Gel desinfetante 250ml',
        description: 'Álcool gel com aloé vera.',
        price: 3.20,
        photoUrl: 'https://via.placeholder.com/240x140.png?text=Gel',
        isAvailable: true,
      ),
    ],
  };
  final Map<String, Map<String, OrderModel>> _ordersByRestaurant = {};
  final Map<String, int> _orderStatusCache = {};

  List<RestaurantModel> get restaurants =>
      List.unmodifiable([..._restaurants, ..._partnerRestaurants]);

  List<PartnerProduct> partnerProductsForRestaurant(
    String restaurantId, {
    bool onlyAvailable = false,
  }) {
    final products = List<PartnerProduct>.of(
      _productsByRestaurant[restaurantId] ?? const <PartnerProduct>[],
    );
    if (!onlyAvailable) {
      return List.unmodifiable(products);
    }
    return List.unmodifiable(
      products.where((product) => product.isAvailable),
    );
  }

  List<OrderModel> ordersForRestaurant(String restaurantId) {
    final orders = _ordersByRestaurant[restaurantId]?.values ??
        const Iterable<OrderModel>.empty();
    return orders
        .where(
          (order) =>
              order.status == OrderStatus.created ||
              order.status == OrderStatus.preparing ||
              order.status == OrderStatus.callingDriver,
        )
        .toList(growable: false)
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
  }

  RestaurantModel? restaurantByName(String? vendorName) {
    if (vendorName == null) return null;
    final normalized = vendorName.toLowerCase();
    try {
      return restaurants.firstWhere(
        (restaurant) =>
            restaurant.isPartner &&
            restaurant.name.toLowerCase() == normalized,
      );
    } catch (_) {
      return null;
    }
  }

  RestaurantModel? restaurantByEmail(String? email) {
    if (email == null) return null;
    final normalized = email.toLowerCase();
    try {
      return restaurants.firstWhere(
        (restaurant) => restaurant.email.toLowerCase() == normalized,
      );
    } catch (_) {
      return null;
    }
  }

  bool hasPartnerWithEmail(String email) {
    final normalized = email.trim().toLowerCase();
    return restaurants
        .any((restaurant) => restaurant.email.toLowerCase() == normalized);
  }

  Future<RestaurantModel> registerPartnerRestaurant({
    required String name,
    required String address,
    required String phone,
    required String email,
    required String photoUrl,
    required String cuisineType,
    required BusinessCategory category,
  }) async {
    final normalizedEmail = email.trim().toLowerCase();
    if (hasPartnerWithEmail(normalizedEmail)) {
      throw StateError('Já existe um restaurante parceiro com este email.');
    }

    final trimmedName = name.trim();
    final generatedPhoto = photoUrl.trim().isEmpty
        ? 'https://via.placeholder.com/240x140.png?text=${Uri.encodeComponent(trimmedName)}'
        : photoUrl.trim();

    final restaurant = RestaurantModel(
      id: 'partner-${DateTime.now().microsecondsSinceEpoch}',
      name: trimmedName,
      phone: phone.trim(),
      address: address.trim(),
      email: normalizedEmail,
      photoUrl: generatedPhoto,
      cuisineType: cuisineType.trim().isEmpty ? 'Variado' : cuisineType.trim(),
      isPartner: true,
      category: category,
    );

    debugPrint('SALVANDO RESTAURANTE NO SUPABASE');

    try {
      final response = await supabase.from('restaurants').insert({
        'name': restaurant.name,
        'address': restaurant.address,
        'phone': restaurant.phone,
        'is_partner': restaurant.isPartner,
      });

      debugPrint('RESPOSTA SUPABASE: $response');
    } catch (e) {
      debugPrint('ERRO SUPABASE: $e');
    }

    _partnerRestaurants.add(restaurant);
    _productsByRestaurant.putIfAbsent(restaurant.id, () => <PartnerProduct>[]);
    notifyListeners();

    return restaurant;
  }

  PartnerProduct addPartnerProduct({
    required String restaurantId,
    required String name,
    required String description,
    required double price,
    required String photoUrl,
    required bool isAvailable,
  }) {
    final trimmedName = name.trim();
    final trimmedDescription = description.trim();
    final normalizedPhoto = photoUrl.trim().isEmpty
        ? 'https://via.placeholder.com/240x140.png?text=${Uri.encodeComponent(trimmedName)}'
        : photoUrl.trim();

    final product = PartnerProduct(
      id: 'prod-${DateTime.now().microsecondsSinceEpoch}',
      name: trimmedName,
      description: trimmedDescription,
      price: price,
      photoUrl: normalizedPhoto,
      isAvailable: isAvailable,
    );

    final list = _productsByRestaurant.putIfAbsent(
        restaurantId, () => <PartnerProduct>[]);
    list.add(product);
    notifyListeners();
    return product;
  }

  bool updatePartnerProduct({
    required String restaurantId,
    required String productId,
    String? name,
    String? description,
    double? price,
    String? photoUrl,
    bool? isAvailable,
  }) {
    final list = _productsByRestaurant[restaurantId];
    if (list == null) return false;

    final index = list.indexWhere((item) => item.id == productId);
    if (index == -1) return false;

    final current = list[index];

    final updated = current.copyWith(
      name: name?.trim().isEmpty == true ? current.name : name?.trim(),
      description: description?.trim().isEmpty == true
          ? current.description
          : description?.trim(),
      price: price,
      photoUrl: photoUrl?.trim().isEmpty == true
          ? current.photoUrl
          : photoUrl?.trim(),
      isAvailable: isAvailable,
    );

    list[index] = updated;
    notifyListeners();
    return true;
  }

  bool deletePartnerProduct({
    required String restaurantId,
    required String productId,
  }) {
    final list = _productsByRestaurant[restaurantId];
    if (list == null) return false;

    final initialLength = list.length;
    list.removeWhere((item) => item.id == productId);
    if (list.length == initialLength) {
      return false;
    }

    notifyListeners();
    return true;
  }

  void syncPartnerOrders(List<OrderModel> orders) {
    final grouped = <String, Map<String, OrderModel>>{};
    final statusCache = <String, int>{};

    for (final order in orders) {
      if (!_isRestaurantPartnerOrder(order)) {
        continue;
      }
      if (!_shouldKeepOrder(order)) {
        continue;
      }

      final restaurant = restaurantByName(order.vendorName);
      if (restaurant == null) {
        continue;
      }

      final bucket = grouped.putIfAbsent(
        restaurant.id,
        () => <String, OrderModel>{},
      );
      bucket[order.id] = order;
      statusCache[order.id] = _fingerprintOrder(order);
    }

    final structureChanged = !_hasSameStructure(grouped);
    final statusChanged = !_hasSameStatusCache(statusCache);

    if (structureChanged || statusChanged) {
      _ordersByRestaurant
        ..clear()
        ..addEntries(
          grouped.entries.map(
            (entry) => MapEntry(
              entry.key,
              Map<String, OrderModel>.from(entry.value),
            ),
          ),
        );
      _orderStatusCache
        ..clear()
        ..addAll(statusCache);
      notifyListeners();
    }
  }

  Future<void> loadRestaurantsFromSupabase() async {
    try {
      final List<dynamic> response =
          await supabase.from('restaurants').select();

      _partnerRestaurants.clear();

      for (final record in response) {
        final data = record as Map<String, dynamic>;
        final restaurant = RestaurantModel(
          id: (data['id'] ?? '').toString(),
          name: data['name'] ?? '',
          address: data['address'] ?? '',
          phone: data['phone'] ?? '',
          email: data['email'] ?? '',
          photoUrl: data['photo_url'] ?? '',
          cuisineType: data['cuisine_type'] ?? '',
          isPartner: data['is_partner'] ?? true,
          category: BusinessCategory.restaurant,
        );

        _partnerRestaurants.add(restaurant);
      }

      notifyListeners();
      debugPrint('RESTAURANTES CARREGADOS: ${_partnerRestaurants.length}');
    } catch (e) {
      debugPrint('ERRO AO CARREGAR RESTAURANTES: $e');
    }
  }

  bool _isRestaurantPartnerOrder(OrderModel order) {
    return order.serviceType == OrderServiceType.restaurant &&
        order.isPartnerStore;
  }

  bool _shouldKeepOrder(OrderModel order) {
    return order.status.index <= OrderStatus.callingDriver.index;
  }

  bool _hasSameStructure(Map<String, Map<String, OrderModel>> next) {
    if (_ordersByRestaurant.length != next.length) {
      return false;
    }
    for (final entry in _ordersByRestaurant.entries) {
      final nextBucket = next[entry.key];
      if (nextBucket == null) {
        return false;
      }
      if (entry.value.length != nextBucket.length) {
        return false;
      }
      for (final orderId in entry.value.keys) {
        if (!nextBucket.containsKey(orderId)) {
          return false;
        }
      }
    }
    return true;
  }

  bool _hasSameStatusCache(Map<String, int> next) {
    if (_orderStatusCache.length != next.length) {
      return false;
    }
    for (final entry in _orderStatusCache.entries) {
      if (next[entry.key] != entry.value) {
        return false;
      }
    }
    return true;
  }

  int _fingerprintOrder(OrderModel order) {
    return Object.hash(
      order.status,
      order.assignedDriverId,
      order.currentDriverOfferId,
      order.driverOfferHistory.length,
      order.pickupWarningIssued,
    );
  }
}
