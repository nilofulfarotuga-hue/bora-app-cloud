import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:http/http.dart' as http;

class PaymentService {
  static const String _currency = 'eur';
  static const String _backendBaseUrl =
      String.fromEnvironment('BACKEND_BASE_URL', defaultValue: '');

  Future<bool> payWithCard(double amount) async {
    if (kIsWeb) {
      debugPrint('Stripe card payments are only supported on mobile platforms.');
      return false;
    }

    try {
      final clientSecret = await _requestPaymentIntent(amount);
      if (clientSecret == null) {
        return false;
      }

      await Stripe.instance.initPaymentSheet(
        paymentSheetParameters: SetupPaymentSheetParameters(
          paymentIntentClientSecret: clientSecret,
          merchantDisplayName: 'BORA APP',
          style: ThemeMode.system,
        ),
      );

      await Stripe.instance.presentPaymentSheet();
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<bool> payWithMBWay(double amount) async {
    await Future.delayed(const Duration(milliseconds: 300));
    return true;
  }

  Future<bool> payWithCash(double amount) async {
    await Future.delayed(const Duration(milliseconds: 150));
    return true;
  }

  Future<String?> _requestPaymentIntent(double amount) async {
    final baseUrl = _backendBaseUrl.trim();
    if (baseUrl.isEmpty) {
      throw StateError(
        'Backend base URL not provided. Set BACKEND_BASE_URL at build time.',
      );
    }

    final sanitizedAmount = amount.isFinite && amount > 0 ? amount : 0.0;
    final cents = (sanitizedAmount * 100).round().clamp(0, 1000000000);

    final uri = Uri.parse(baseUrl).resolve('payment-intent');

    final response = await http.post(
      uri,
      headers: const {
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'amount': cents,
        'currency': _currency,
      }),
    );

    if (response.statusCode >= 200 && response.statusCode < 300) {
      final body = jsonDecode(response.body) as Map<String, dynamic>;
      return body['client_secret'] as String?;
    }

    debugPrint('PaymentIntent request failed: ${response.body}');
    return null;
  }
}
