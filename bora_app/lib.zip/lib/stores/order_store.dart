import 'dart:async';

import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../dispatch/dispatch_engine.dart';
import '../models/cart_item.dart';
import '../models/chat_message.dart';
import '../models/order_model.dart';
import '../models/partner_product.dart';
import '../models/rating_model.dart';
import '../models/restaurant_model.dart';
import '../services/distance_service.dart';
import '../services/pricing_service.dart';
import 'driver_store.dart';
import 'restaurant_store.dart';

class PartnerOrderLine {
  const PartnerOrderLine({
    required this.product,
    required this.quantity,
  }) : assert(quantity > 0);

  final PartnerProduct product;
  final int quantity;

  double get lineTotal => product.price * quantity;
}

class OrderStore extends ChangeNotifier {

  final supabase = Supabase.instance.client;
  RealtimeChannel? _channel;
  static const Map<OrderStatus, Set<OrderStatus>> _statusFlow = {
    OrderStatus.created: {
      OrderStatus.preparing,
      OrderStatus.rejected,
    },
    OrderStatus.preparing: {OrderStatus.callingDriver},
    OrderStatus.callingDriver: {OrderStatus.driverAccepted},
    OrderStatus.driverAccepted: {OrderStatus.pickedUp},
    OrderStatus.pickedUp: {OrderStatus.onTheWay},
    OrderStatus.onTheWay: {OrderStatus.delivered},
    OrderStatus.delivered: <OrderStatus>{},
    OrderStatus.rejected: <OrderStatus>{},
  };

  OrderStore({
    required DriverStore driverStore,
  }) : _driverStore = driverStore {
    loadOrders();
    listenForNewOrders();

    // BUG 3 CORRIGIDO: O timer local não remove mais pedidos da lista.
    // A remoção de pedidos expirados deve vir do Supabase via Realtime,
    // não de uma limpeza local que cria inconsistência entre dispositivos.
    Timer.periodic(const Duration(seconds: 3), (_) {
      refresh();
    });
  }

  Future<void> loadOrders() async {
    final response = await supabase
        .from('orders')
        .select()
        .order('created_at', ascending: false);
    _orders.clear();
    for (final data in response) {
      final order = OrderModel.fromSupabase(data);
      _orders.add(order);
    }
    notifyListeners();
  }

  DriverStore _driverStore;
  RestaurantStore? _restaurantStore;
  DispatchEngine? _dispatchEngine;
  final List<OrderModel> _orders = [];
  final Map<String, List<ChatMessage>> _chatMessages = {};
  final List<RatingModel> _ratings = [];
  final Map<String, Timer> _partnerPreparationTimers = {};
  final Map<String, Set<String>> _dismissedOrdersByDriver = {};

  void listenForNewOrders() {
    _channel = supabase.channel('realtime:public:orders');

    _channel!
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'orders',
          callback: (payload) {
            final data = payload.newRecord;
            final order = OrderModel.fromSupabase(data);

            final exists = _orders.any((o) => o.id == order.id);

            if (!exists) {
              _orders.insert(0, order);
              notifyListeners();
            }
          },
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'orders',
          callback: (payload) {
            final data = payload.newRecord;
            final updatedOrder = OrderModel.fromSupabase(data);

            final index = _orders.indexWhere((o) => o.id == updatedOrder.id);

            if (index != -1) {
              _orders[index] = updatedOrder;
              notifyListeners();
            }
          },
        )
        .subscribe();
  }


  List<OrderModel> get orders => List.unmodifiable(_orders);

  String get _currentDriverId => _driverStore.currentDriverId;

  bool get isDriverAvailable => _driverStore.currentDriver.isOnline;

  List<OrderModel> get availableOrders {
    final driver = _driverStore.getDriverById(_currentDriverId);
    if (driver == null) {
      return const <OrderModel>[];
    }

    final now = DateTime.now();
    final available = _orders.where((order) {
      if (order.status != OrderStatus.callingDriver) return false;

      if (order.driverOfferExpiresAt != null &&
          now.isAfter(order.driverOfferExpiresAt!)) {
        return false;
      }

      if (!driver.supportsService(order.serviceType)) return false;

      if (order.currentDriverOfferId != null &&
          order.currentDriverOfferId != _currentDriverId) {
        return false;
      }

      return true;
    }).toList();

    final dismissed = _dismissedOrdersByDriver[_currentDriverId];
    if (dismissed != null && dismissed.isNotEmpty) {
      final existingIds = _orders.map((order) => order.id).toSet();
      dismissed.removeWhere((orderId) => !existingIds.contains(orderId));
      available.removeWhere((order) => dismissed.contains(order.id));
    }

    available.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return available;
  }

  List<OrderModel> get myOrders => _orders
      .where((o) =>
          o.assignedDriverId == _currentDriverId &&
          (o.status == OrderStatus.driverAccepted ||
              o.status == OrderStatus.pickedUp ||
              o.status == OrderStatus.onTheWay))
      .toList();

  List<OrderModel> get completedOrders =>
      _orders.where((o) => o.status == OrderStatus.delivered).toList();

  OrderModel? get activeDriverOrder {
    for (final order in _orders) {
      if (order.assignedDriverId == _currentDriverId &&
          (order.status == OrderStatus.driverAccepted ||
              order.status == OrderStatus.pickedUp ||
              order.status == OrderStatus.onTheWay)) {
        return order;
      }
    }
    return null;
  }

  void updateDriverStore(DriverStore driverStore) {
    _driverStore = driverStore;
  }

  void updateRestaurantStore(RestaurantStore store) {
    _restaurantStore = store;
    _restaurantStore?.syncPartnerOrders(_orders);
  }

  void updateDispatchEngine(DispatchEngine dispatchEngine) {
    _dispatchEngine = dispatchEngine;
  }

  @override
  void notifyListeners() {
    super.notifyListeners();
    _restaurantStore?.syncPartnerOrders(_orders);
  }

  void toggleDriverAvailability(bool value) {
    final success = _driverStore.toggleAvailability(_currentDriverId, value);
    if (success) {
      notifyListeners();
    }
  }

  void createOrder({
    required OrderServiceType serviceType,
    required double itemsSubtotal,
    required LatLng destination,
    required PaymentMethod paymentMethod,
    List<CartItem>? items,
    LatLng? pickupLocation,
    double? distanceKm,
    bool isPartnerStore = false,
    bool apartmentDelivery = false,
    String? vendorName,
    String? pickupAddress,
    String? pickupStreet,
    String? pickupCity,
    String? pickupPostalCode,
    String? dropoffAddress,
    String? dropoffStreet,
    String? dropoffCity,
    String? dropoffPostalCode,
    String? customerNotes,
    String? clientPhone,
    String? customerName,
  }) {
    final resolvedDistance = _resolveDistance(
      pickup: pickupLocation,
      destination: destination,
      providedDistance: distanceKm,
    );

    final pricing = PricingService.calculateBreakdown(
      serviceType: serviceType,
      subtotal: itemsSubtotal,
      distanceKm: resolvedDistance,
      isPartnerStore: isPartnerStore,
      apartmentDelivery: apartmentDelivery,
    );

    final orderType = _resolveOrderType(
      serviceType: serviceType,
      isPartnerStore: isPartnerStore,
    );

    final clonedItems = items
        ?.map(
          (item) => CartItem(
            name: item.name,
            price: item.price,
            quantity: item.quantity,
          ),
        )
        .toList();

    final order = OrderModel(
      total: pricing.customerTotal,
      serviceType: serviceType,
      subtotal: pricing.subtotal,
      deliveryFee: pricing.deliveryFee,
      serviceFee: pricing.serviceFee,
      platformCommission: pricing.platformCommission,
      driverEarnings: pricing.driverEarnings,
      distanceKm: pricing.distanceKm,
      items: clonedItems,
      pickupLocation: pickupLocation,
      destination: destination,
      vendorName: vendorName,
      pickupAddress: pickupAddress,
      pickupStreet: pickupStreet,
      pickupCity: pickupCity,
      pickupPostalCode: pickupPostalCode,
      dropoffAddress: dropoffAddress,
      dropoffStreet: dropoffStreet,
      dropoffCity: dropoffCity,
      dropoffPostalCode: dropoffPostalCode,
      customerNotes: customerNotes,
      isPartnerStore: isPartnerStore,
      apartmentDelivery: apartmentDelivery,
      orderType: orderType,
      paymentMethod: paymentMethod,
      clientPhone: clientPhone,
      customerName: customerName,
    );

    _orders.insert(0, order);
    notifyListeners();

    // BUG 2 CORRIGIDO: agora usa unawaited explicitamente com tratamento de erro.
    // A criação local é imediata para UX responsiva; o Realtime propagará
    // o INSERT para os outros dispositivos assim que o banco confirmar.
    _saveOrderToDatabase(order).then((_) {
      _simulateRestaurantFlow(order);
    }).catchError((e) {
      // Se falhar, remove o pedido local para manter consistência
      _orders.remove(order);
      notifyListeners();
      print('Erro ao salvar pedido: $e');
    });
  }

  Future<void> _simulateRestaurantFlow(OrderModel order) async {
    final isPartnerRestaurantOrder =
        order.serviceType == OrderServiceType.restaurant &&
            order.isPartnerStore;

    if (isPartnerRestaurantOrder) {
      // Await action from restaurant dashboard.
      return;
    }

    final requiresPreparation =
        order.serviceType == OrderServiceType.restaurant ||
            (order.serviceType == OrderServiceType.storeShopping &&
                order.isPartnerStore);

    if (!requiresPreparation) {
      final progressed = await _advanceStatus(order, OrderStatus.preparing);
      if (!progressed) return;

      await Future.delayed(const Duration(milliseconds: 500));
      await _advanceStatus(order, OrderStatus.callingDriver);
      return;
    }

    final progressed = await _advanceStatus(order, OrderStatus.preparing);
    if (!progressed) return;

    await Future.delayed(const Duration(seconds: 3));

    await _advanceStatus(order, OrderStatus.callingDriver);
  }

  // BUG 4 CORRIGIDO: _advanceStatus agora é async e aguarda a confirmação
  // do banco ANTES de atualizar o estado local e notificar listeners.
  // Isso garante que ambos os celulares vejam o mesmo estado.
  Future<bool> _advanceStatus(OrderModel order, OrderStatus targetStatus) async {
    if (!_orders.contains(order)) return false;

    if (order.status == targetStatus) {
      return false;
    }

    if (!_canTransition(order.status, targetStatus)) {
      return false;
    }

    if (targetStatus == OrderStatus.callingDriver) {
      order.driverOfferExpiresAt =
          DateTime.now().add(const Duration(seconds: 40));
    }

    // Persiste no banco PRIMEIRO, só então atualiza local
    final success = await _updateOrderStatusInDatabase(
      order,
      targetStatus,
      driverOfferExpiresAt: order.driverOfferExpiresAt,
    );

    if (!success) return false;

    // Agora atualiza o estado local (o Realtime também vai propagar para
    // outros dispositivos via onPostgresChanges update)
    order.status = targetStatus;
    notifyListeners();
    _handlePartnerPreparationFlow(order);
    return true;
  }

  bool _canTransition(OrderStatus current, OrderStatus target) {
    if (current == target) return true;
    final allowedTargets = _statusFlow[current];
    if (allowedTargets == null) return false;
    return allowedTargets.contains(target);
  }

  Future<bool> markPreparing(OrderModel order) {
    return _advanceStatus(order, OrderStatus.preparing);
  }

  Future<bool> markReadyForDriver(OrderModel order) async {
    final advanced = await _advanceStatus(order, OrderStatus.callingDriver);

    if (advanced) {
      order.currentDriverOfferId = _currentDriverId;
      order.driverOfferExpiresAt =
          DateTime.now().add(const Duration(seconds: 40));
    }

    return advanced;
  }

  bool rejectAvailableOrder(OrderModel order) {
    if (order.status != OrderStatus.callingDriver) {
      return false;
    }

    if (order.assignedDriverId != null &&
        order.assignedDriverId != _currentDriverId) {
      return false;
    }

    final driverId = _currentDriverId;
    final dismissed = _dismissedOrdersByDriver.putIfAbsent(
      driverId,
      () => <String>{},
    );

    dismissed.add(order.id);

    if (!order.driverOfferHistory.contains(driverId)) {
      order.driverOfferHistory.add(driverId);
    }

    order.driverOfferExpiresAt = null;

    if (order.currentDriverOfferId == driverId) {
      if (_dispatchEngine != null) {
        _dispatchEngine!.notifyOrderReleased(order);
        return true;
      }
      order.currentDriverOfferId = null;
    }

    notifyListeners();
    return true;
  }

  Future<bool> acceptOrder(OrderModel order) async {
    if (!isDriverAvailable) {
      return false;
    }
    if (order.currentDriverOfferId != null &&
        order.currentDriverOfferId != _currentDriverId) {
      return false;
    }
    if (order.assignedDriverId != null &&
        order.assignedDriverId != _currentDriverId) {
      return false;
    }
    if (!_driverStore.canAcceptOrder(_currentDriverId, order)) {
      return false;
    }
    if (activeDriverOrder != null && activeDriverOrder != order) {
      return false;
    }
    final advanced = await _advanceStatus(order, OrderStatus.driverAccepted);
    if (advanced) {
      order.assignedDriverId = _currentDriverId;
      order.currentDriverOfferId = null;
      final registered =
          _driverStore.registerOrderForDriver(_currentDriverId, order);
      if (registered) {
        _driverStore.startTracking(order);
      }
      _dispatchEngine?.notifyOrderAccepted(order);
    }
    return advanced;
  }

  Future<bool> pickUpOrder(OrderModel order) async {
    final advanced = await _advanceStatus(order, OrderStatus.pickedUp);
    if (advanced) {
      order.pickupWarningIssued = false;
      _driverStore.updateTrackingTarget(order);
      _dispatchEngine?.notifyOrderPickedUp(order);
    }
    return advanced;
  }

  Future<bool> startDelivery(OrderModel order) async {
    final advanced = await _advanceStatus(order, OrderStatus.onTheWay);
    if (advanced) {
      _driverStore.updateTrackingTarget(order);
    }
    return advanced;
  }

  Future<bool> finishOrder(OrderModel order) async {
    final advanced = await _advanceStatus(order, OrderStatus.delivered);
    if (advanced && order.assignedDriverId != null) {
      _driverStore.releaseOrderForDriver(order.assignedDriverId!, order.id);
      _driverStore.stopTracking(order.id);
      _dispatchEngine?.notifyOrderReleased(order);
      order.pickupWarningIssued = false;
    }
    return advanced;
  }

  // BUG 3 CORRIGIDO: refresh() não remove mais pedidos localmente.
  // Apenas notifica para que a UI recalcule availableOrders filtrando
  // os expirados via getter (sem apagar do banco ou da lista).
  void refresh() {
    notifyListeners();
  }

  OrderType _resolveOrderType({
    required OrderServiceType serviceType,
    required bool isPartnerStore,
  }) {
    if (serviceType == OrderServiceType.restaurant && isPartnerStore) {
      return OrderType.partnerRestaurant;
    }
    return OrderType.nonPartnerPurchase;
  }

  bool restaurantAcceptOrder(OrderModel order) {
    if (!order.isPartnerStore ||
        order.serviceType != OrderServiceType.restaurant) {
      return false;
    }
    if (order.status != OrderStatus.created) {
      return false;
    }
    _advanceStatus(order, OrderStatus.preparing);
    return true;
  }

  bool restaurantRejectOrder(OrderModel order) {
    if (!order.isPartnerStore ||
        order.serviceType != OrderServiceType.restaurant) {
      return false;
    }
    if (order.status != OrderStatus.created) {
      return false;
    }
    _advanceStatus(order, OrderStatus.rejected);
    return true;
  }

  bool restaurantMarkReady(OrderModel order) {
    if (!order.isPartnerStore ||
        order.serviceType != OrderServiceType.restaurant) {
      return false;
    }
    if (order.status != OrderStatus.preparing) {
      return false;
    }
    _advanceStatus(order, OrderStatus.callingDriver);
    return true;
  }

  List<OrderModel> partnerOrdersForRestaurant(String restaurantName) {
    final normalized = restaurantName.trim().toLowerCase();
    final filtered = _orders.where((order) {
      final vendor = order.vendorName;
      if (vendor == null) return false;
      if (order.serviceType != OrderServiceType.restaurant) return false;
      if (!order.isPartnerStore) return false;
      return vendor.trim().toLowerCase() == normalized;
    }).toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return filtered;
  }

  OrderModel createPartnerDeliveryRequest({
    required RestaurantModel restaurant,
    required String customerName,
    required String customerPhone,
    required String deliveryAddress,
    required List<PartnerOrderLine> items,
    String? notes,
  }) {
    if (items.isEmpty) {
      throw ArgumentError(
          'Partner delivery request requires at least one item.');
    }

    final subtotal = items.fold<double>(0, (sum, line) => sum + line.lineTotal);
    if (subtotal <= 0) {
      throw ArgumentError('Subtotal must be greater than zero.');
    }

    final pricing = PricingService.calculateBreakdown(
      serviceType: OrderServiceType.restaurant,
      subtotal: subtotal,
      distanceKm: PricingService.defaultDistanceKm,
      isPartnerStore: true,
      apartmentDelivery: false,
    );

    final orderNotes = _composePartnerOrderNotes(items: items, notes: notes);

    final order = OrderModel(
      total: pricing.customerTotal,
      serviceType: OrderServiceType.restaurant,
      subtotal: pricing.subtotal,
      deliveryFee: pricing.deliveryFee,
      serviceFee: pricing.serviceFee,
      platformCommission: pricing.platformCommission,
      driverEarnings: pricing.driverEarnings,
      distanceKm: pricing.distanceKm,
      vendorName: restaurant.name,
      pickupAddress: restaurant.address,
      dropoffAddress: deliveryAddress,
      customerNotes: orderNotes,
      isPartnerStore: true,
      apartmentDelivery: false,
      orderType: OrderType.partnerRestaurant,
      paymentMethod: PaymentMethod.cash,
      status: OrderStatus.callingDriver,
      clientPhone: customerPhone,
      customerName: customerName,
      items: items
          .map(
            (line) => CartItem(
              name: line.product.name,
              price: line.product.price,
              quantity: line.quantity,
            ),
          )
          .toList(),
    );

    _orders.insert(0, order);
    notifyListeners();
    return order;
  }

  List<ChatMessage> messagesForOrder(String orderId) {
    return List.unmodifiable(_chatMessages[orderId] ?? const <ChatMessage>[]);
  }

  void sendChatMessage({
    required String orderId,
    required ChatSenderType senderType,
    required String message,
  }) {
    final trimmed = message.trim();
    if (trimmed.isEmpty) return;

    final messages = _chatMessages.putIfAbsent(orderId, () => <ChatMessage>[]);
    messages.add(
      ChatMessage(
        id: DateTime.now().microsecondsSinceEpoch.toString(),
        orderId: orderId,
        senderType: senderType,
        message: trimmed,
        timestamp: DateTime.now(),
      ),
    );
    notifyListeners();
  }

  RatingModel? ratingForOrder(String orderId) {
    try {
      return _ratings.firstWhere((rating) => rating.orderId == orderId);
    } catch (_) {
      return null;
    }
  }

  void submitRating({
    required String orderId,
    required String driverId,
    required int rating,
    String? comment,
  }) {
    _ratings.removeWhere((existing) => existing.orderId == orderId);
    _ratings.add(
      RatingModel(
        orderId: orderId,
        driverId: driverId,
        rating: rating,
        comment: comment?.trim().isEmpty == true ? null : comment?.trim(),
      ),
    );
    notifyListeners();
  }

  void _handlePartnerPreparationFlow(OrderModel order) {
    if (!_isPartnerRestaurantOrder(order)) {
      _cancelPartnerPreparationTimer(order.id);
      return;
    }

    if (order.status == OrderStatus.preparing) {
      _schedulePartnerPreparationTimer(order);
    } else {
      _cancelPartnerPreparationTimer(order.id);
    }
  }

  void _schedulePartnerPreparationTimer(OrderModel order) {
    _cancelPartnerPreparationTimer(order.id);
    _partnerPreparationTimers[order.id] = Timer(const Duration(minutes: 5), () {
      if (!_orders.contains(order)) return;
      if (order.status != OrderStatus.preparing) return;
      _advanceStatus(order, OrderStatus.callingDriver);
    });
  }

  void _cancelPartnerPreparationTimer(String orderId) {
    _partnerPreparationTimers.remove(orderId)?.cancel();
  }

  @override
  void dispose() {
    _channel?.unsubscribe();
    for (final timer in _partnerPreparationTimers.values) {
      timer.cancel();
    }
    _partnerPreparationTimers.clear();
    super.dispose();
  }

  bool _isPartnerRestaurantOrder(OrderModel order) {
    return order.serviceType == OrderServiceType.restaurant &&
        order.isPartnerStore;
  }

  double _resolveDistance({
    LatLng? pickup,
    required LatLng destination,
    double? providedDistance,
  }) {
    if (providedDistance != null && providedDistance > 0) {
      return providedDistance;
    }

    if (pickup != null) {
      return DistanceService.calculateDistanceKm(
        pickup.latitude,
        pickup.longitude,
        destination.latitude,
        destination.longitude,
      );
    }

    return PricingService.defaultDistanceKm;
  }

  String _composePartnerOrderNotes({
    required List<PartnerOrderLine> items,
    String? notes,
  }) {
    final buffer = StringBuffer('Itens do pedido:\n');
    for (final line in items) {
      final lineTotal = _roundCurrency(line.lineTotal);
      buffer.writeln(
          '- ${line.quantity}× ${line.product.name} (€${line.product.price.toStringAsFixed(2)} cada) • €${lineTotal.toStringAsFixed(2)}');
    }
    final normalizedNotes = notes?.trim();
    if (normalizedNotes != null && normalizedNotes.isNotEmpty) {
      buffer
        ..writeln()
        ..writeln('Observações: $normalizedNotes');
    }
    return buffer.toString().trim();
  }

  double _roundCurrency(double value) => (value * 100).roundToDouble() / 100;

  // BUG 1 CORRIGIDO: função movida para DENTRO da classe.
  // Antes estava fora do `}` da classe, tornando-a uma função top-level
  // sem acesso ao contexto e nunca chamada corretamente.
  Future<void> _saveOrderToDatabase(OrderModel order) async {
    try {
      final response = await supabase.from('orders').insert({
        'created_at': order.createdAt.toIso8601String(),
        'service_type': order.serviceType.name,
        'status': order.status.name,
        'pickup_address': order.pickupAddress,
        'dropoff_address': order.dropoffAddress,
        'price': order.total,
      }).select();

      print('INSERT RESPONSE: $response');
    } catch (e) {
      print('ERRO SUPABASE INSERT: $e');
      rethrow; // Propaga para o .catchError em createOrder
    }
  }

  // BUG 1 + BUG 4 CORRIGIDO: função movida para dentro da classe e agora
  // retorna Future<bool> para que _advanceStatus possa aguardar confirmação
  // antes de atualizar o estado local.
  Future<bool> _updateOrderStatusInDatabase(
    OrderModel order,
    OrderStatus newStatus, {
    DateTime? driverOfferExpiresAt,
  }) async {
    try {
      final payload = <String, dynamic>{'status': newStatus.name};
      if (driverOfferExpiresAt != null) {
        payload['driver_offer_expires_at'] = driverOfferExpiresAt.toIso8601String();
      }
      await supabase
          .from('orders')
          .update(payload)
          .eq('id', order.id);
      return true;
    } catch (e) {
      print('ERRO SUPABASE UPDATE: $e');
      return false;
    }
  }
} // fim da classe OrderStore