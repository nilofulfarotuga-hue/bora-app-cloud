import 'dart:async';

import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../dispatch/dispatch_engine.dart';
import '../models/cart_item.dart';
import '../models/chat_message.dart';
import '../models/order_model.dart';
import '../models/partner_product.dart';
import '../models/rating_model.dart';
import '../models/restaurant_model.dart';
import '../services/distance_service.dart';
import '../services/pricing_service.dart';
import 'driver_store.dart';
import 'restaurant_store.dart';

class PartnerOrderLine {
  const PartnerOrderLine({
    required this.product,
    required this.quantity,
  }) : assert(quantity > 0);

  final PartnerProduct product;
  final int quantity;

  double get lineTotal => product.price * quantity;
}

class OrderStore extends ChangeNotifier {
  final supabase = Supabase.instance.client;

  // ── FIX: channel name must NOT include the "realtime:" prefix.
  // Supabase JS SDK docs and Flutter SDK both require the raw channel name,
  // e.g. 'orders_channel'. Using 'realtime:public:orders' as the name
  // confuses the SDK and the channel never actually subscribes correctly.
  static const _ordersChannelName = 'orders_channel';

  RealtimeChannel? _channel;
  Timer? _refreshTimer;

  static const Map<OrderStatus, Set<OrderStatus>> _statusFlow = {
    OrderStatus.created: {
      OrderStatus.preparing,
      OrderStatus.rejected,
    },
    OrderStatus.preparing: {OrderStatus.callingDriver},
    OrderStatus.callingDriver: {OrderStatus.driverAccepted},
    OrderStatus.driverAccepted: {OrderStatus.pickedUp},
    OrderStatus.pickedUp: {OrderStatus.onTheWay},
    OrderStatus.onTheWay: {OrderStatus.delivered},
    OrderStatus.delivered: <OrderStatus>{},
    OrderStatus.rejected: <OrderStatus>{},
  };

  OrderStore({
    required DriverStore driverStore,
  }) : _driverStore = driverStore {
    _bootstrap();
  }

  /// Initialisation: load existing rows first, then open the Realtime channel.
  /// Doing it in this order prevents a race where the channel fires an INSERT
  /// for a row we already loaded (which would be deduped), vs opening the
  /// channel first and potentially missing rows.
  Future<void> _bootstrap() async {
    await loadOrders();
    _subscribeRealtime();
    _refreshTimer = Timer.periodic(const Duration(seconds: 3), (_) => refresh());
  }

  Future<void> loadOrders() async {
    try {
      final response = await supabase
          .from('orders')
          .select()
          .order('created_at', ascending: false);
      _orders.clear();
      for (final data in response) {
        final order = OrderModel.fromSupabase(data);
        _orders.add(order);
      }
      notifyListeners();
    } catch (e) {
      debugPrint('OrderStore: loadOrders error => $e');
    }
  }

  DriverStore _driverStore;
  RestaurantStore? _restaurantStore;
  DispatchEngine? _dispatchEngine;
  final List<OrderModel> _orders = [];
  final Map<String, List<ChatMessage>> _chatMessages = {};
  final List<RatingModel> _ratings = [];
  final Map<String, Timer> _partnerPreparationTimers = {};
  final Map<String, Set<String>> _dismissedOrdersByDriver = {};

  // ─────────────────────────────────────────────────────────────────────────
  // FIX (CRITICAL — ROOT CAUSE OF "NO REALTIME"): The channel subscription
  // had three compounding problems:
  //
  //  1. Wrong channel name: 'realtime:public:orders' — the 'realtime:' prefix
  //     is internal Supabase routing notation, not a valid channel name for
  //     the Flutter client. Correct name is any unique string, e.g. 'orders_channel'.
  //
  //  2. Missing DELETE handler: orders that get soft-deleted or expired in the
  //     DB were never removed from the local list.
  //
  //  3. No subscribe() error handling / status logging — silent failures.
  //
  //  4. The channel was recreated on every Provider rebuild because
  //     listenForNewOrders() was called from the constructor without guarding
  //     against re-initialization. Now _subscribeRealtime() is idempotent.
  // ─────────────────────────────────────────────────────────────────────────
  void _subscribeRealtime() {
    // Guard: never create a second channel if already subscribed.
    if (_channel != null) return;

    _channel = supabase.channel(_ordersChannelName);

    _channel!
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'orders',
          callback: (payload) {
            final data = payload.newRecord;
            if (data.isEmpty) return;
            final order = OrderModel.fromSupabase(data);
            final exists = _orders.any((o) => o.id == order.id);
            if (!exists) {
              _orders.insert(0, order);
              notifyListeners();
            }
          },
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'orders',
          callback: (payload) {
            final data = payload.newRecord;
            if (data.isEmpty) return;
            final updatedOrder = OrderModel.fromSupabase(data);
            final index = _orders.indexWhere((o) => o.id == updatedOrder.id);
            if (index != -1) {
              _orders[index] = updatedOrder;
              notifyListeners();
            }
          },
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.delete,
          schema: 'public',
          table: 'orders',
          callback: (payload) {
            final oldData = payload.oldRecord;
            if (oldData.isEmpty) return;
            final deletedId = oldData['id'] as String?;
            if (deletedId == null) return;
            final before = _orders.length;
            _orders.removeWhere((o) => o.id == deletedId);
            if (_orders.length != before) notifyListeners();
          },
        )
        .subscribe((status, [error]) {
          debugPrint('OrderStore Realtime: $status${error != null ? ' | $error' : ''}');
          // If the subscription error-loops, back off and retry.
          if (status == RealtimeSubscribeStatus.channelError ||
              status == RealtimeSubscribeStatus.timedOut) {
            _resubscribeWithDelay();
          }
        });
  }

  void _resubscribeWithDelay() {
    _channel?.unsubscribe();
    _channel = null;
    Future.delayed(const Duration(seconds: 5), () {
      if (!_disposed) _subscribeRealtime();
    });
  }

  bool _disposed = false;

  List<OrderModel> get orders => List.unmodifiable(_orders);

  String get _currentDriverId => _driverStore.currentDriverId;

  bool get isDriverAvailable => _driverStore.currentDriver.isOnline;

  List<OrderModel> get availableOrders {
    final driver = _driverStore.getDriverById(_currentDriverId);
    if (driver == null) {
      return const <OrderModel>[];
    }

    final now = DateTime.now();
    final available = _orders.where((order) {
      if (order.status != OrderStatus.callingDriver) return false;

      if (order.driverOfferExpiresAt != null &&
          now.isAfter(order.driverOfferExpiresAt!)) {
        return false;
      }

      if (!driver.supportsService(order.serviceType)) return false;

      if (order.currentDriverOfferId != null &&
          order.currentDriverOfferId != _currentDriverId) {
        return false;
      }

      return true;
    }).toList();

    final dismissed = _dismissedOrdersByDriver[_currentDriverId];
    if (dismissed != null && dismissed.isNotEmpty) {
      final existingIds = _orders.map((order) => order.id).toSet();
      dismissed.removeWhere((orderId) => !existingIds.contains(orderId));
      available.removeWhere((order) => dismissed.contains(order.id));
    }

    available.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return available;
  }

  List<OrderModel> get myOrders => _orders
      .where((o) =>
          o.assignedDriverId == _currentDriverId &&
          (o.status == OrderStatus.driverAccepted ||
              o.status == OrderStatus.pickedUp ||
              o.status == OrderStatus.onTheWay))
      .toList();

  List<OrderModel> get completedOrders =>
      _orders.where((o) => o.status == OrderStatus.delivered).toList();

  OrderModel? get activeDriverOrder {
    for (final order in _orders) {
      if (order.assignedDriverId == _currentDriverId &&
          (order.status == OrderStatus.driverAccepted ||
              order.status == OrderStatus.pickedUp ||
              order.status == OrderStatus.onTheWay)) {
        return order;
      }
    }
    return null;
  }

  void updateDriverStore(DriverStore driverStore) {
    _driverStore = driverStore;
  }

  void updateRestaurantStore(RestaurantStore store) {
    _restaurantStore = store;
    _restaurantStore?.syncPartnerOrders(_orders);
  }

  void updateDispatchEngine(DispatchEngine dispatchEngine) {
    _dispatchEngine = dispatchEngine;
  }

  @override
  void notifyListeners() {
    super.notifyListeners();
    _restaurantStore?.syncPartnerOrders(_orders);
  }

  void toggleDriverAvailability(bool value) {
    final success = _driverStore.toggleAvailability(_currentDriverId, value);
    if (success) {
      notifyListeners();
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // FIX: createOrder now awaits _saveOrderToDatabase and uses the DB-returned
  // id (if the DB generates it) to keep local and remote in sync.
  // The optimistic local insert is reverted on DB failure.
  // ─────────────────────────────────────────────────────────────────────────
  Future<void> createOrder({
    required OrderServiceType serviceType,
    required double itemsSubtotal,
    required LatLng destination,
    required PaymentMethod paymentMethod,
    List<CartItem>? items,
    LatLng? pickupLocation,
    double? distanceKm,
    bool isPartnerStore = false,
    bool apartmentDelivery = false,
    String? vendorName,
    String? pickupAddress,
    String? pickupStreet,
    String? pickupCity,
    String? pickupPostalCode,
    String? dropoffAddress,
    String? dropoffStreet,
    String? dropoffCity,
    String? dropoffPostalCode,
    String? customerNotes,
    String? clientPhone,
    String? customerName,
  }) async {
    final resolvedDistance = _resolveDistance(
      pickup: pickupLocation,
      destination: destination,
      providedDistance: distanceKm,
    );

    final pricing = PricingService.calculateBreakdown(
      serviceType: serviceType,
      subtotal: itemsSubtotal,
      distanceKm: resolvedDistance,
      isPartnerStore: isPartnerStore,
      apartmentDelivery: apartmentDelivery,
    );

    final orderType = _resolveOrderType(
      serviceType: serviceType,
      isPartnerStore: isPartnerStore,
    );

    final clonedItems = items
        ?.map(
          (item) => CartItem(
            name: item.name,
            price: item.price,
            quantity: item.quantity,
          ),
        )
        .toList();

    final order = OrderModel(
      total: pricing.customerTotal,
      serviceType: serviceType,
      subtotal: pricing.subtotal,
      deliveryFee: pricing.deliveryFee,
      serviceFee: pricing.serviceFee,
      platformCommission: pricing.platformCommission,
      driverEarnings: pricing.driverEarnings,
      distanceKm: pricing.distanceKm,
      items: clonedItems,
      pickupLocation: pickupLocation,
      destination: destination,
      vendorName: vendorName,
      pickupAddress: pickupAddress,
      pickupStreet: pickupStreet,
      pickupCity: pickupCity,
      pickupPostalCode: pickupPostalCode,
      dropoffAddress: dropoffAddress,
      dropoffStreet: dropoffStreet,
      dropoffCity: dropoffCity,
      dropoffPostalCode: dropoffPostalCode,
      customerNotes: customerNotes,
      isPartnerStore: isPartnerStore,
      apartmentDelivery: apartmentDelivery,
      orderType: orderType,
      paymentMethod: paymentMethod,
      clientPhone: clientPhone,
      customerName: customerName,
    );

    // Optimistic local insert for responsive UI.
    _orders.insert(0, order);
    notifyListeners();

    try {
      await _saveOrderToDatabase(order);
      // Realtime INSERT event will propagate to other devices automatically.
      await _simulateRestaurantFlow(order);
    } catch (e) {
      // Revert the optimistic insert so UI stays consistent with DB.
      _orders.remove(order);
      notifyListeners();
      debugPrint('OrderStore: createOrder failed => $e');
    }
  }

  Future<void> _simulateRestaurantFlow(OrderModel order) async {
    final isPartnerRestaurantOrder =
        order.serviceType == OrderServiceType.restaurant &&
            order.isPartnerStore;

    if (isPartnerRestaurantOrder) {
      // Awaits action from restaurant dashboard — do nothing here.
      return;
    }

    final requiresPreparation =
        order.serviceType == OrderServiceType.restaurant ||
            (order.serviceType == OrderServiceType.storeShopping &&
                order.isPartnerStore);

    if (!requiresPreparation) {
      final progressed = await _advanceStatus(order, OrderStatus.preparing);
      if (!progressed) return;
      await Future.delayed(const Duration(milliseconds: 500));
      await _advanceStatus(order, OrderStatus.callingDriver);
      return;
    }

    final progressed = await _advanceStatus(order, OrderStatus.preparing);
    if (!progressed) return;
    await Future.delayed(const Duration(seconds: 3));
    await _advanceStatus(order, OrderStatus.callingDriver);
  }

  // ─────────────────────────────────────────────────────────────────────────
  // FIX: _advanceStatus is async and writes to the DB BEFORE updating local
  // state. If the DB write fails, local state is NOT changed, keeping both
  // devices consistent. The Realtime UPDATE event triggered by the DB write
  // will propagate the change to all other subscribers automatically.
  // ─────────────────────────────────────────────────────────────────────────
  Future<bool> _advanceStatus(
      OrderModel order, OrderStatus targetStatus) async {
    if (!_orders.contains(order)) return false;
    if (order.status == targetStatus) return false;
    if (!_canTransition(order.status, targetStatus)) return false;

    DateTime? newExpiry;
    if (targetStatus == OrderStatus.callingDriver) {
      newExpiry = DateTime.now().add(const Duration(seconds: 40));
    }

    final success = await _updateOrderStatusInDatabase(
      order,
      targetStatus,
      driverOfferExpiresAt: newExpiry,
    );
    if (!success) return false;

    // Update local state only after DB confirmed.
    order.status = targetStatus;
    if (newExpiry != null) order.driverOfferExpiresAt = newExpiry;
    notifyListeners();
    _handlePartnerPreparationFlow(order);
    return true;
  }

  bool _canTransition(OrderStatus current, OrderStatus target) {
    if (current == target) return true;
    final allowedTargets = _statusFlow[current];
    if (allowedTargets == null) return false;
    return allowedTargets.contains(target);
  }

  Future<bool> markPreparing(OrderModel order) =>
      _advanceStatus(order, OrderStatus.preparing);

  Future<bool> markReadyForDriver(OrderModel order) async {
    final advanced = await _advanceStatus(order, OrderStatus.callingDriver);
    if (advanced) {
      order.currentDriverOfferId = _currentDriverId;
      // driverOfferExpiresAt is already set in _advanceStatus.
    }
    return advanced;
  }

  bool rejectAvailableOrder(OrderModel order) {
    if (order.status != OrderStatus.callingDriver) return false;

    if (order.assignedDriverId != null &&
        order.assignedDriverId != _currentDriverId) {
      return false;
    }

    final driverId = _currentDriverId;
    final dismissed = _dismissedOrdersByDriver.putIfAbsent(
      driverId,
      () => <String>{},
    );
    dismissed.add(order.id);

    if (!order.driverOfferHistory.contains(driverId)) {
      order.driverOfferHistory.add(driverId);
    }

    order.driverOfferExpiresAt = null;

    if (order.currentDriverOfferId == driverId) {
      if (_dispatchEngine != null) {
        _dispatchEngine!.notifyOrderReleased(order);
        return true;
      }
      order.currentDriverOfferId = null;
    }

    notifyListeners();
    return true;
  }

  Future<bool> acceptOrder(OrderModel order) async {
    if (!isDriverAvailable) return false;
    if (order.currentDriverOfferId != null &&
        order.currentDriverOfferId != _currentDriverId) {
      return false;
    }
    if (order.assignedDriverId != null &&
        order.assignedDriverId != _currentDriverId) {
      return false;
    }
    if (!_driverStore.canAcceptOrder(_currentDriverId, order)) return false;
    if (activeDriverOrder != null && activeDriverOrder != order) return false;

    final advanced = await _advanceStatus(order, OrderStatus.driverAccepted);
    if (advanced) {
      order.assignedDriverId = _currentDriverId;
      order.currentDriverOfferId = null;
      // Persist the driver assignment immediately.
      await _persistDriverAssignment(order);
      final registered =
          _driverStore.registerOrderForDriver(_currentDriverId, order);
      if (registered) {
        _driverStore.startTracking(order);
      }
      _dispatchEngine?.notifyOrderAccepted(order);
    }
    return advanced;
  }

  Future<bool> pickUpOrder(OrderModel order) async {
    final advanced = await _advanceStatus(order, OrderStatus.pickedUp);
    if (advanced) {
      order.pickupWarningIssued = false;
      _driverStore.updateTrackingTarget(order);
      _dispatchEngine?.notifyOrderPickedUp(order);
    }
    return advanced;
  }

  Future<bool> startDelivery(OrderModel order) async {
    final advanced = await _advanceStatus(order, OrderStatus.onTheWay);
    if (advanced) {
      _driverStore.updateTrackingTarget(order);
    }
    return advanced;
  }

  Future<bool> finishOrder(OrderModel order) async {
    final advanced = await _advanceStatus(order, OrderStatus.delivered);
    if (advanced && order.assignedDriverId != null) {
      _driverStore.releaseOrderForDriver(order.assignedDriverId!, order.id);
      _driverStore.stopTracking(order.id);
      _dispatchEngine?.notifyOrderReleased(order);
      order.pickupWarningIssued = false;
    }
    return advanced;
  }

  /// Lightweight UI refresh — recalculates derived getters without hitting DB.
  void refresh() {
    notifyListeners();
  }

  OrderType _resolveOrderType({
    required OrderServiceType serviceType,
    required bool isPartnerStore,
  }) {
    if (serviceType == OrderServiceType.restaurant && isPartnerStore) {
      return OrderType.partnerRestaurant;
    }
    return OrderType.nonPartnerPurchase;
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Restaurant partner actions — now return Future<bool> and await DB writes.
  // ─────────────────────────────────────────────────────────────────────────
  Future<bool> restaurantAcceptOrder(OrderModel order) async {
    if (!order.isPartnerStore ||
        order.serviceType != OrderServiceType.restaurant) {
      return false;
    }
    if (order.status != OrderStatus.created) return false;
    return _advanceStatus(order, OrderStatus.preparing);
  }

  Future<bool> restaurantRejectOrder(OrderModel order) async {
    if (!order.isPartnerStore ||
        order.serviceType != OrderServiceType.restaurant) {
      return false;
    }
    if (order.status != OrderStatus.created) return false;
    return _advanceStatus(order, OrderStatus.rejected);
  }

  Future<bool> restaurantMarkReady(OrderModel order) async {
    if (!order.isPartnerStore ||
        order.serviceType != OrderServiceType.restaurant) {
      return false;
    }
    if (order.status != OrderStatus.preparing) return false;
    return _advanceStatus(order, OrderStatus.callingDriver);
  }

  List<OrderModel> partnerOrdersForRestaurant(String restaurantName) {
    final normalized = restaurantName.trim().toLowerCase();
    return _orders.where((order) {
      final vendor = order.vendorName;
      if (vendor == null) return false;
      if (order.serviceType != OrderServiceType.restaurant) return false;
      if (!order.isPartnerStore) return false;
      return vendor.trim().toLowerCase() == normalized;
    }).toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
  }

  // ─────────────────────────────────────────────────────────────────────────
  // FIX: createPartnerDeliveryRequest previously only inserted into the local
  // list — it NEVER persisted to Supabase. Other devices never saw it.
  // Now it calls _saveOrderToDatabase just like createOrder does.
  // ─────────────────────────────────────────────────────────────────────────
  Future<OrderModel> createPartnerDeliveryRequest({
    required RestaurantModel restaurant,
    required String customerName,
    required String customerPhone,
    required String deliveryAddress,
    required List<PartnerOrderLine> items,
    String? notes,
  }) async {
    if (items.isEmpty) {
      throw ArgumentError(
          'Partner delivery request requires at least one item.');
    }

    final subtotal =
        items.fold<double>(0, (sum, line) => sum + line.lineTotal);
    if (subtotal <= 0) {
      throw ArgumentError('Subtotal must be greater than zero.');
    }

    final pricing = PricingService.calculateBreakdown(
      serviceType: OrderServiceType.restaurant,
      subtotal: subtotal,
      distanceKm: PricingService.defaultDistanceKm,
      isPartnerStore: true,
      apartmentDelivery: false,
    );

    final orderNotes = _composePartnerOrderNotes(items: items, notes: notes);

    final order = OrderModel(
      total: pricing.customerTotal,
      serviceType: OrderServiceType.restaurant,
      subtotal: pricing.subtotal,
      deliveryFee: pricing.deliveryFee,
      serviceFee: pricing.serviceFee,
      platformCommission: pricing.platformCommission,
      driverEarnings: pricing.driverEarnings,
      distanceKm: pricing.distanceKm,
      vendorName: restaurant.name,
      pickupAddress: restaurant.address,
      dropoffAddress: deliveryAddress,
      customerNotes: orderNotes,
      isPartnerStore: true,
      apartmentDelivery: false,
      orderType: OrderType.partnerRestaurant,
      paymentMethod: PaymentMethod.cash,
      status: OrderStatus.callingDriver,
      clientPhone: customerPhone,
      customerName: customerName,
      items: items
          .map(
            (line) => CartItem(
              name: line.product.name,
              price: line.product.price,
              quantity: line.quantity,
            ),
          )
          .toList(),
    );

    _orders.insert(0, order);
    notifyListeners();

    try {
      await _saveOrderToDatabase(order);
    } catch (e) {
      _orders.remove(order);
      notifyListeners();
      debugPrint('OrderStore: createPartnerDeliveryRequest failed => $e');
      rethrow;
    }

    return order;
  }

  List<ChatMessage> messagesForOrder(String orderId) {
    return List.unmodifiable(_chatMessages[orderId] ?? const <ChatMessage>[]);
  }

  void sendChatMessage({
    required String orderId,
    required ChatSenderType senderType,
    required String message,
  }) {
    final trimmed = message.trim();
    if (trimmed.isEmpty) return;

    final messages = _chatMessages.putIfAbsent(orderId, () => <ChatMessage>[]);
    messages.add(
      ChatMessage(
        id: DateTime.now().microsecondsSinceEpoch.toString(),
        orderId: orderId,
        senderType: senderType,
        message: trimmed,
        timestamp: DateTime.now(),
      ),
    );
    notifyListeners();
  }

  RatingModel? ratingForOrder(String orderId) {
    try {
      return _ratings.firstWhere((rating) => rating.orderId == orderId);
    } catch (_) {
      return null;
    }
  }

  void submitRating({
    required String orderId,
    required String driverId,
    required int rating,
    String? comment,
  }) {
    _ratings.removeWhere((existing) => existing.orderId == orderId);
    _ratings.add(
      RatingModel(
        orderId: orderId,
        driverId: driverId,
        rating: rating,
        comment: comment?.trim().isEmpty == true ? null : comment?.trim(),
      ),
    );
    notifyListeners();
  }

  void _handlePartnerPreparationFlow(OrderModel order) {
    if (!_isPartnerRestaurantOrder(order)) {
      _cancelPartnerPreparationTimer(order.id);
      return;
    }

    if (order.status == OrderStatus.preparing) {
      _schedulePartnerPreparationTimer(order);
    } else {
      _cancelPartnerPreparationTimer(order.id);
    }
  }

  void _schedulePartnerPreparationTimer(OrderModel order) {
    _cancelPartnerPreparationTimer(order.id);
    _partnerPreparationTimers[order.id] =
        Timer(const Duration(minutes: 5), () {
      if (!_orders.contains(order)) return;
      if (order.status != OrderStatus.preparing) return;
      _advanceStatus(order, OrderStatus.callingDriver);
    });
  }

  void _cancelPartnerPreparationTimer(String orderId) {
    _partnerPreparationTimers.remove(orderId)?.cancel();
  }

  @override
  void dispose() {
    _disposed = true;
    _refreshTimer?.cancel();
    _channel?.unsubscribe();
    for (final timer in _partnerPreparationTimers.values) {
      timer.cancel();
    }
    _partnerPreparationTimers.clear();
    super.dispose();
  }

  bool _isPartnerRestaurantOrder(OrderModel order) {
    return order.serviceType == OrderServiceType.restaurant &&
        order.isPartnerStore;
  }

  double _resolveDistance({
    LatLng? pickup,
    required LatLng destination,
    double? providedDistance,
  }) {
    if (providedDistance != null && providedDistance > 0) {
      return providedDistance;
    }
    if (pickup != null) {
      return DistanceService.calculateDistanceKm(
        pickup.latitude,
        pickup.longitude,
        destination.latitude,
        destination.longitude,
      );
    }
    return PricingService.defaultDistanceKm;
  }

  String _composePartnerOrderNotes({
    required List<PartnerOrderLine> items,
    String? notes,
  }) {
    final buffer = StringBuffer('Itens do pedido:\n');
    for (final line in items) {
      final lineTotal = _roundCurrency(line.lineTotal);
      buffer.writeln(
          '- ${line.quantity}× ${line.product.name} (€${line.product.price.toStringAsFixed(2)} cada) • €${lineTotal.toStringAsFixed(2)}');
    }
    final normalizedNotes = notes?.trim();
    if (normalizedNotes != null && normalizedNotes.isNotEmpty) {
      buffer
        ..writeln()
        ..writeln('Observações: $normalizedNotes');
    }
    return buffer.toString().trim();
  }

  double _roundCurrency(double value) => (value * 100).roundToDouble() / 100;

  // ─────────────────────────────────────────────────────────────────────────
  // DB helpers — both inside the class (previously _updateOrderStatusInDatabase
  // was accidentally placed OUTSIDE the class closing brace, making it a
  // top-level function that was never called).
  // ─────────────────────────────────────────────────────────────────────────

  Future<void> _saveOrderToDatabase(OrderModel order) async {
    // Use toSupabase() to send ALL fields, not just 5 hardcoded ones.
    await supabase.from('orders').insert(order.toSupabase());
    debugPrint('OrderStore: inserted order ${order.id}');
  }

  Future<bool> _updateOrderStatusInDatabase(
    OrderModel order,
    OrderStatus newStatus, {
    DateTime? driverOfferExpiresAt,
  }) async {
    try {
      final payload = <String, dynamic>{'status': newStatus.name};
      if (driverOfferExpiresAt != null) {
        payload['driver_offer_expires_at'] =
            driverOfferExpiresAt.toIso8601String();
      }
      await supabase.from('orders').update(payload).eq('id', order.id);
      return true;
    } catch (e) {
      debugPrint('OrderStore: _updateOrderStatusInDatabase error => $e');
      return false;
    }
  }

  /// Persists driver assignment fields after acceptOrder.
  Future<void> _persistDriverAssignment(OrderModel order) async {
    try {
      await supabase.from('orders').update({
        'assigned_driver_id': order.assignedDriverId,
        'current_driver_offer_id': order.currentDriverOfferId,
        'driver_phone': order.driverPhone,
      }).eq('id', order.id);
    } catch (e) {
      debugPrint('OrderStore: _persistDriverAssignment error => $e');
    }
  }
}