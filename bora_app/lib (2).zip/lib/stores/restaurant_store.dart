import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/order_model.dart';
import '../models/partner_product.dart';
import '../models/restaurant_model.dart';

class RestaurantStore extends ChangeNotifier {
  final supabase = Supabase.instance.client;

  final List<RestaurantModel> _partnerRestaurants = [];

  RealtimeChannel? _restaurantsChannel;
  RealtimeChannel? _productsChannel;

  RestaurantStore()
      : _restaurants = [
          const RestaurantModel(
            id: 'rest-mcdonalds',
            name: "McDonald's",
            phone: '210000001',
            address: 'Av. Fontes Pereira de Melo 5, Lisboa',
            email: 'contato@mcdonalds.pt',
            photoUrl:
                'https://via.placeholder.com/240x140.png?text=McDonald%27s',
            cuisineType: 'Fast Food',
            isPartner: false,
            category: BusinessCategory.restaurant,
          ),
          const RestaurantModel(
            id: 'rest-burger-king',
            name: 'Burger King',
            phone: '210000002',
            address: 'R. Joaquim António de Aguiar 16, Lisboa',
            email: 'contato@burgerking.pt',
            photoUrl:
                'https://via.placeholder.com/240x140.png?text=Burger+King',
            cuisineType: 'Hambúrgueres',
            isPartner: false,
            category: BusinessCategory.restaurant,
          ),
          const RestaurantModel(
            id: 'rest-pizzahut',
            name: 'Pizza Hut',
            phone: '210000003',
            address: 'Av. de Berna 12, Lisboa',
            email: 'contato@pizzahut.pt',
            photoUrl: 'https://via.placeholder.com/240x140.png?text=Pizza+Hut',
            cuisineType: 'Pizzaria',
            isPartner: true,
            category: BusinessCategory.restaurant,
          ),
          const RestaurantModel(
            id: 'rest-kfc',
            name: 'KFC',
            phone: '210000004',
            address: 'Praça Martim Moniz 2, Lisboa',
            email: 'contato@kfc.pt',
            photoUrl: 'https://via.placeholder.com/240x140.png?text=KFC',
            cuisineType: 'Frango Frito',
            isPartner: true,
            category: BusinessCategory.restaurant,
          ),
          const RestaurantModel(
            id: 'market-mini-mercado',
            name: 'Mini Mercado Lisboa',
            phone: '210000101',
            address: 'Rua da Madalena 220, Lisboa',
            email: 'contacto@minimercadolx.pt',
            photoUrl:
                'https://via.placeholder.com/240x140.png?text=Mini+Mercado',
            cuisineType: 'Mercearia',
            isPartner: true,
            category: BusinessCategory.supermarket,
          ),
          const RestaurantModel(
            id: 'market-super-bairro',
            name: 'Super Bairro Market',
            phone: '210000102',
            address: 'Rua Marquês Sá da Bandeira 88, Lisboa',
            email: 'contacto@superbairro.pt',
            photoUrl:
                'https://via.placeholder.com/240x140.png?text=Supermercado',
            cuisineType: 'Supermercado',
            isPartner: true,
            category: BusinessCategory.supermarket,
          ),
          const RestaurantModel(
            id: 'store-lisboa-shop',
            name: 'Lisboa Lifestyle Store',
            phone: '210000201',
            address: 'Rua Augusta 150, Lisboa',
            email: 'contato@lisboastore.pt',
            photoUrl: 'https://via.placeholder.com/240x140.png?text=Loja',
            cuisineType: 'Vestuário e presentes',
            isPartner: false,
            category: BusinessCategory.store,
          ),
          const RestaurantModel(
            id: 'pharmacy-central',
            name: 'Farmácia Central',
            phone: '210000301',
            address: 'Rossio 28, Lisboa',
            email: 'atendimento@farmaciacentral.pt',
            photoUrl: 'https://via.placeholder.com/240x140.png?text=Farmacia',
            cuisineType: 'Produtos de saúde',
            isPartner: false,
            category: BusinessCategory.pharmacy,
          ),
        ] {
    loadRestaurantsFromSupabase();
    loadProductsFromSupabase();
  }

  final List<RestaurantModel> _restaurants;

  // Hardcoded data removed — now populated exclusively from Supabase.
  final Map<String, List<PartnerProduct>> _productsByRestaurant = {};

  final Map<String, Map<String, OrderModel>> _ordersByRestaurant = {};
  final Map<String, int> _orderStatusCache = {};

  // ─── Getters ──────────────────────────────────────────────────────────────

  List<RestaurantModel> get restaurants =>
      List.unmodifiable([..._restaurants, ..._partnerRestaurants]);

  List<PartnerProduct> partnerProductsForRestaurant(
    String restaurantId, {
    bool onlyAvailable = false,
  }) {
    final products = List<PartnerProduct>.of(
      _productsByRestaurant[restaurantId] ?? const <PartnerProduct>[],
    );
    if (!onlyAvailable) {
      return List.unmodifiable(products);
    }
    return List.unmodifiable(
      products.where((product) => product.isAvailable),
    );
  }

  List<OrderModel> ordersForRestaurant(String restaurantId) {
    final orders = _ordersByRestaurant[restaurantId]?.values ??
        const Iterable<OrderModel>.empty();
    return orders
        .where(
          (order) =>
              order.status == OrderStatus.created ||
              order.status == OrderStatus.preparing ||
              order.status == OrderStatus.callingDriver,
        )
        .toList(growable: false)
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
  }

  RestaurantModel? restaurantByName(String? vendorName) {
    if (vendorName == null) return null;
    final normalized = vendorName.toLowerCase();
    try {
      return restaurants.firstWhere(
        (restaurant) =>
            restaurant.isPartner &&
            restaurant.name.toLowerCase() == normalized,
      );
    } catch (_) {
      return null;
    }
  }

  RestaurantModel? restaurantByEmail(String? email) {
    if (email == null) return null;
    final normalized = email.toLowerCase();
    try {
      return restaurants.firstWhere(
        (restaurant) => restaurant.email.toLowerCase() == normalized,
      );
    } catch (_) {
      return null;
    }
  }

  bool hasPartnerWithEmail(String email) {
    final normalized = email.trim().toLowerCase();
    return restaurants
        .any((restaurant) => restaurant.email.toLowerCase() == normalized);
  }

  // ─── Load from Supabase ───────────────────────────────────────────────────

  Future<void> loadRestaurantsFromSupabase() async {
    try {
      final List<dynamic> response =
          await supabase.from('restaurants').select();

      _partnerRestaurants.clear();

      for (final record in response) {
        final data = record as Map<String, dynamic>;
        final categoryStr = data['category'] as String? ?? 'restaurant';
        final category = BusinessCategory.values.firstWhere(
          (e) => e.name == categoryStr,
          orElse: () => BusinessCategory.restaurant,
        );

        final restaurant = RestaurantModel(
          id: (data['id'] ?? '').toString(),
          name: data['name'] ?? '',
          address: data['address'] ?? '',
          phone: data['phone'] ?? '',
          email: data['email'] ?? '',
          photoUrl: data['photo_url'] ?? '',
          cuisineType: data['cuisine_type'] ?? '',
          isPartner: data['is_partner'] ?? true,
          category: category,
        );

        _partnerRestaurants.add(restaurant);
      }

      notifyListeners();
      debugPrint(
          'RestaurantStore: loaded ${_partnerRestaurants.length} restaurants');
    } catch (e) {
      debugPrint('RestaurantStore: loadRestaurantsFromSupabase error => $e');
    }

    _subscribeRestaurantsRealtime();
  }

  Future<void> loadProductsFromSupabase() async {
    try {
      final List<dynamic> response = await supabase.from('products').select();

      _productsByRestaurant.clear();

      for (final record in response) {
        final data = record as Map<String, dynamic>;

        final restaurantId = (data['restaurant_id'] ?? '').toString();
        if (restaurantId.isEmpty) continue;

        final product = PartnerProduct(
          id: (data['id'] ?? '').toString(),
          name: data['name'] ?? '',
          description: data['description'] ?? '',
          price: (data['price'] as num? ?? 0).toDouble(),
          photoUrl: data['photo_url'] ?? '',
          isAvailable: data['is_available'] ?? true,
        );

        _productsByRestaurant
            .putIfAbsent(restaurantId, () => <PartnerProduct>[])
            .add(product);
      }

      notifyListeners();
      debugPrint(
          'RestaurantStore: loaded products for ${_productsByRestaurant.length} restaurants');
    } catch (e) {
      debugPrint('RestaurantStore: loadProductsFromSupabase error => $e');
    }

    _subscribeProductsRealtime();
  }

  // ─── Realtime subscriptions ───────────────────────────────────────────────

  void _subscribeRestaurantsRealtime() {
    if (_restaurantsChannel != null) return;

    _restaurantsChannel = supabase.channel('restaurants_channel')
      ..onPostgresChanges(
        event: PostgresChangeEvent.insert,
        schema: 'public',
        table: 'restaurants',
        callback: (payload) {
          final data = payload.newRecord;
          if (data.isEmpty) return;
          final categoryStr = data['category'] as String? ?? 'restaurant';
          final category = BusinessCategory.values.firstWhere(
            (e) => e.name == categoryStr,
            orElse: () => BusinessCategory.restaurant,
          );
          final restaurant = RestaurantModel(
            id: (data['id'] ?? '').toString(),
            name: data['name'] ?? '',
            address: data['address'] ?? '',
            phone: data['phone'] ?? '',
            email: data['email'] ?? '',
            photoUrl: data['photo_url'] ?? '',
            cuisineType: data['cuisine_type'] ?? '',
            isPartner: data['is_partner'] ?? true,
            category: category,
          );
          final exists = _partnerRestaurants.any((r) => r.id == restaurant.id);
          if (!exists) {
            _partnerRestaurants.add(restaurant);
            notifyListeners();
          }
        },
      )
      ..subscribe((status, [error]) {
        debugPrint(
            'RestaurantStore restaurants Realtime: $status${error != null ? ' | $error' : ''}');
      });
  }

  void _subscribeProductsRealtime() {
    if (_productsChannel != null) return;

    _productsChannel = supabase.channel('products_channel')
      ..onPostgresChanges(
        event: PostgresChangeEvent.insert,
        schema: 'public',
        table: 'products',
        callback: (payload) {
          final data = payload.newRecord;
          if (data.isEmpty) return;
          final restaurantId = (data['restaurant_id'] ?? '').toString();
          if (restaurantId.isEmpty) return;
          final product = PartnerProduct(
            id: (data['id'] ?? '').toString(),
            name: data['name'] ?? '',
            description: data['description'] ?? '',
            price: (data['price'] as num? ?? 0).toDouble(),
            photoUrl: data['photo_url'] ?? '',
            isAvailable: data['is_available'] ?? true,
          );
          final list = _productsByRestaurant.putIfAbsent(
              restaurantId, () => <PartnerProduct>[]);
          final exists = list.any((p) => p.id == product.id);
          if (!exists) {
            list.add(product);
            notifyListeners();
          }
        },
      )
      ..onPostgresChanges(
        event: PostgresChangeEvent.update,
        schema: 'public',
        table: 'products',
        callback: (payload) {
          final data = payload.newRecord;
          if (data.isEmpty) return;
          final restaurantId = (data['restaurant_id'] ?? '').toString();
          if (restaurantId.isEmpty) return;
          final productId = (data['id'] ?? '').toString();
          final list = _productsByRestaurant[restaurantId];
          if (list == null) return;
          final index = list.indexWhere((p) => p.id == productId);
          if (index == -1) return;
          list[index] = PartnerProduct(
            id: productId,
            name: data['name'] ?? '',
            description: data['description'] ?? '',
            price: (data['price'] as num? ?? 0).toDouble(),
            photoUrl: data['photo_url'] ?? '',
            isAvailable: data['is_available'] ?? true,
          );
          notifyListeners();
        },
      )
      ..onPostgresChanges(
        event: PostgresChangeEvent.delete,
        schema: 'public',
        table: 'products',
        callback: (payload) {
          final old = payload.oldRecord;
          if (old.isEmpty) return;
          final productId = (old['id'] ?? '').toString();
          final restaurantId = (old['restaurant_id'] ?? '').toString();
          final list = _productsByRestaurant[restaurantId];
          if (list == null) return;
          final before = list.length;
          list.removeWhere((p) => p.id == productId);
          if (list.length != before) notifyListeners();
        },
      )
      ..subscribe((status, [error]) {
        debugPrint(
            'RestaurantStore products Realtime: $status${error != null ? ' | $error' : ''}');
      });
  }

  // ─── Mutations ────────────────────────────────────────────────────────────

  Future<RestaurantModel> registerPartnerRestaurant({
    required String name,
    required String address,
    required String phone,
    required String email,
    required String photoUrl,
    required String cuisineType,
    required BusinessCategory category,
  }) async {
    final normalizedEmail = email.trim().toLowerCase();
    if (hasPartnerWithEmail(normalizedEmail)) {
      throw StateError('Já existe um restaurante parceiro com este email.');
    }

    final trimmedName = name.trim();
    final generatedPhoto = photoUrl.trim().isEmpty
        ? 'https://via.placeholder.com/240x140.png?text=${Uri.encodeComponent(trimmedName)}'
        : photoUrl.trim();

    final restaurant = RestaurantModel(
      id: 'partner-${DateTime.now().microsecondsSinceEpoch}',
      name: trimmedName,
      phone: phone.trim(),
      address: address.trim(),
      email: normalizedEmail,
      photoUrl: generatedPhoto,
      cuisineType: cuisineType.trim().isEmpty ? 'Variado' : cuisineType.trim(),
      isPartner: true,
      category: category,
    );

    debugPrint('RestaurantStore: registering partner ${restaurant.name}');

    try {
      await supabase.from('restaurants').insert({
        'id': restaurant.id,
        'name': restaurant.name,
        'address': restaurant.address,
        'phone': restaurant.phone,
        'email': restaurant.email,
        'photo_url': restaurant.photoUrl,
        'cuisine_type': restaurant.cuisineType,
        'is_partner': restaurant.isPartner,
        'category': restaurant.category.name,
      });
      debugPrint('RestaurantStore: partner saved to Supabase');
      await loadRestaurantsFromSupabase();
    } catch (e) {
      debugPrint('RestaurantStore: Supabase insert error => $e');
      // Add locally so the session works even if DB is temporarily down.
      _partnerRestaurants.add(restaurant);
      notifyListeners();
    }

    return restaurant;
  }

  // addPartnerProduct inserts into local list immediately (sync contract required
  // by PartnerProductStore) then persists to Supabase in the background.
  PartnerProduct addPartnerProduct({
    required String restaurantId,
    required String name,
    required String description,
    required double price,
    required String photoUrl,
    required bool isAvailable,
  }) {
    final trimmedName = name.trim();
    final trimmedDescription = description.trim();
    final normalizedPhoto = photoUrl.trim().isEmpty
        ? 'https://via.placeholder.com/240x140.png?text=${Uri.encodeComponent(trimmedName)}'
        : photoUrl.trim();

    final product = PartnerProduct(
      id: 'prod-${DateTime.now().microsecondsSinceEpoch}',
      name: trimmedName,
      description: trimmedDescription,
      price: price,
      photoUrl: normalizedPhoto,
      isAvailable: isAvailable,
    );

    _productsByRestaurant
        .putIfAbsent(restaurantId, () => <PartnerProduct>[])
        .add(product);
    notifyListeners();

    // Persist to Supabase asynchronously — fire and forget.
    supabase.from('products').insert({
      'id': product.id,
      'restaurant_id': restaurantId,
      'name': product.name,
      'description': product.description,
      'price': product.price,
      'photo_url': product.photoUrl,
      'is_available': product.isAvailable,
    }).then((_) {
      debugPrint('RestaurantStore: product saved to Supabase');
      loadProductsFromSupabase();
    }).catchError((Object e) {
      debugPrint('RestaurantStore: product insert error => $e');
    });

    return product;
  }

  bool updatePartnerProduct({
    required String restaurantId,
    required String productId,
    String? name,
    String? description,
    double? price,
    String? photoUrl,
    bool? isAvailable,
  }) {
    final list = _productsByRestaurant[restaurantId];
    if (list == null) return false;

    final index = list.indexWhere((item) => item.id == productId);
    if (index == -1) return false;

    final current = list[index];

    final updated = current.copyWith(
      name: name?.trim().isEmpty == true ? current.name : name?.trim(),
      description: description?.trim().isEmpty == true
          ? current.description
          : description?.trim(),
      price: price,
      photoUrl: photoUrl?.trim().isEmpty == true
          ? current.photoUrl
          : photoUrl?.trim(),
      isAvailable: isAvailable,
    );

    list[index] = updated;
    notifyListeners();

    // Persist update to Supabase asynchronously.
    supabase.from('products').update({
      'name': updated.name,
      'description': updated.description,
      'price': updated.price,
      'photo_url': updated.photoUrl,
      'is_available': updated.isAvailable,
    }).eq('id', productId).then((_) {
      debugPrint('RestaurantStore: product updated in Supabase');
    }).catchError((e) {
      debugPrint('RestaurantStore: product update error => $e');
    });

    return true;
  }

  bool deletePartnerProduct({
    required String restaurantId,
    required String productId,
  }) {
    final list = _productsByRestaurant[restaurantId];
    if (list == null) return false;

    final initialLength = list.length;
    list.removeWhere((item) => item.id == productId);
    if (list.length == initialLength) return false;

    notifyListeners();

    // Persist deletion to Supabase asynchronously.
    supabase.from('products').delete().eq('id', productId).then((_) {
      debugPrint('RestaurantStore: product deleted from Supabase');
    }).catchError((e) {
      debugPrint('RestaurantStore: product delete error => $e');
    });

    return true;
  }

  // ─── Order sync ───────────────────────────────────────────────────────────

  void syncPartnerOrders(List<OrderModel> orders) {
    final grouped = <String, Map<String, OrderModel>>{};
    final statusCache = <String, int>{};

    for (final order in orders) {
      if (!_isRestaurantPartnerOrder(order)) continue;
      if (!_shouldKeepOrder(order)) continue;

      final restaurant = restaurantByName(order.vendorName);
      if (restaurant == null) continue;

      final bucket = grouped.putIfAbsent(
        restaurant.id,
        () => <String, OrderModel>{},
      );
      bucket[order.id] = order;
      statusCache[order.id] = _fingerprintOrder(order);
    }

    final structureChanged = !_hasSameStructure(grouped);
    final statusChanged = !_hasSameStatusCache(statusCache);

    if (structureChanged || statusChanged) {
      _ordersByRestaurant
        ..clear()
        ..addEntries(
          grouped.entries.map(
            (entry) => MapEntry(
              entry.key,
              Map<String, OrderModel>.from(entry.value),
            ),
          ),
        );
      _orderStatusCache
        ..clear()
        ..addAll(statusCache);
      notifyListeners();
    }
  }

  // ─── Dispose ──────────────────────────────────────────────────────────────

  @override
  void dispose() {
    _restaurantsChannel?.unsubscribe();
    _productsChannel?.unsubscribe();
    super.dispose();
  }

  // ─── Private helpers ──────────────────────────────────────────────────────

  bool _isRestaurantPartnerOrder(OrderModel order) {
    return order.serviceType == OrderServiceType.restaurant &&
        order.isPartnerStore;
  }

  bool _shouldKeepOrder(OrderModel order) {
    return order.status.index <= OrderStatus.callingDriver.index;
  }

  bool _hasSameStructure(Map<String, Map<String, OrderModel>> next) {
    if (_ordersByRestaurant.length != next.length) return false;
    for (final entry in _ordersByRestaurant.entries) {
      final nextBucket = next[entry.key];
      if (nextBucket == null) return false;
      if (entry.value.length != nextBucket.length) return false;
      for (final orderId in entry.value.keys) {
        if (!nextBucket.containsKey(orderId)) return false;
      }
    }
    return true;
  }

  bool _hasSameStatusCache(Map<String, int> next) {
    if (_orderStatusCache.length != next.length) return false;
    for (final entry in _orderStatusCache.entries) {
      if (next[entry.key] != entry.value) return false;
    }
    return true;
  }

  int _fingerprintOrder(OrderModel order) {
    return Object.hash(
      order.status,
      order.assignedDriverId,
      order.currentDriverOfferId,
      order.driverOfferHistory.length,
      order.pickupWarningIssued,
    );
  }
}