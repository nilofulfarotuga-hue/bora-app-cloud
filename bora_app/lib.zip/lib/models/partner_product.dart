class PartnerProduct {
  const PartnerProduct({
    required this.id,
    required this.name,
    required this.description,
    required this.price,
    required this.photoUrl,
    required this.isAvailable,
  });

  final String id;
  final String name;
  final String description;
  final double price;
  final String photoUrl;
  final bool isAvailable;

  PartnerProduct copyWith({
    String? name,
    String? description,
    double? price,
    String? photoUrl,
    bool? isAvailable,
  }) {
    return PartnerProduct(
      id: id,
      name: name ?? this.name,
      description: description ?? this.description,
      price: price ?? this.price,
      photoUrl: photoUrl ?? this.photoUrl,
      isAvailable: isAvailable ?? this.isAvailable,
    );
  }
}
