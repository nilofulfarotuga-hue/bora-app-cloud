import 'dart:async';

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart' hide LatLng;
import 'package:latlong2/latlong.dart' as ll;
import 'package:provider/provider.dart';

import '../models/order_model.dart';
import '../services/directions_service.dart';
import '../services/navigation_service.dart';
import '../stores/driver_store.dart';
import '../stores/order_store.dart';
import '../utils/map_utils.dart';
import 'driver_order_action_helper.dart';

class DriverMapScreen extends StatefulWidget {
  const DriverMapScreen({super.key});

  @override
  State<DriverMapScreen> createState() => _DriverMapScreenState();
}

class _DriverMapScreenState extends State<DriverMapScreen> {
  final Completer<GoogleMapController> _mapController = Completer();
  final DirectionsService _directionsService = DirectionsService();

  ll.LatLng? _lastAnimatedPosition;
  ll.LatLng? _lastAnimatedTarget;
  List<ll.LatLng> _routePoints = <ll.LatLng>[];
  String? _activeRouteKey;
  int _routeRequestId = 0;
  StreamSubscription<Position>? _positionSubscription;

  @override
  void initState() {
    super.initState();
    _listenToDriverLocation();
  }

  @override
  void dispose() {
    _positionSubscription?.cancel();
    _directionsService.dispose();
    super.dispose();
  }

  Future<void> _listenToDriverLocation() async {
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      return;
    }

    _positionSubscription = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 5,
      ),
    ).listen((position) {
      if (!mounted) return;

      final driverStore = context.read<DriverStore>();
      final updatedLocation = ll.LatLng(position.latitude, position.longitude);

      driverStore.updateDriverLocation(
        driverStore.currentDriverId,
        updatedLocation,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final orderStore = context.watch<OrderStore>();
    final driverStore = context.watch<DriverStore>();
    final activeOrder = orderStore.activeDriverOrder;
    final driverPosition = driverStore.currentDriver.location;

    if (activeOrder == null) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Mapa da entrega'),
        ),
        body: const Center(
          child: Padding(
            padding: EdgeInsets.all(24),
            child: Text(
              'Aceite um pedido para visualizar a rota.',
              textAlign: TextAlign.center,
            ),
          ),
        ),
      );
    }

    final pickupLocation = activeOrder.pickupLocation;
    final dropoffLocation = activeOrder.destination;
    final driverTarget = activeOrder.status.index <= OrderStatus.pickedUp.index
        ? (pickupLocation ?? dropoffLocation)
        : dropoffLocation;

    if (driverTarget != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        _updateRoute(driverPosition, driverTarget);
      });
    } else if (_routePoints.isNotEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        setState(() {
          _routePoints = <ll.LatLng>[];
          _activeRouteKey = null;
        });
      });
    }

    final markers = <Marker>{
      Marker(
        markerId: const MarkerId('driver'),
        position: driverPosition.toGMaps(),
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
        infoWindow: const InfoWindow(title: 'Estafeta'),
      ),
    };

    if (pickupLocation != null) {
      markers.add(
        Marker(
          markerId: const MarkerId('pickup'),
          position: pickupLocation.toGMaps(),
          icon: BitmapDescriptor.defaultMarkerWithHue(
            BitmapDescriptor.hueOrange,
          ),
          infoWindow: const InfoWindow(title: 'Recolha'),
        ),
      );
    }

    if (dropoffLocation != null) {
      markers.add(
        Marker(
          markerId: const MarkerId('dropoff'),
          position: dropoffLocation.toGMaps(),
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
          infoWindow: const InfoWindow(title: 'Entrega'),
        ),
      );
    }

    final polylines = <Polyline>{};
    if (_routePoints.isNotEmpty) {
      polylines.add(
        Polyline(
          polylineId: const PolylineId('driver-route'),
          color: Colors.blueAccent,
          width: 5,
          points: _routePoints.toGMaps(),
        ),
      );
    } else if (driverTarget != null) {
      polylines.add(
        Polyline(
          polylineId: const PolylineId('driver-route'),
          color: Colors.blueAccent,
          width: 4,
          points: [driverPosition.toGMaps(), driverTarget.toGMaps()],
        ),
      );
    }

    final mapCenter = pickupLocation ?? dropoffLocation ?? driverPosition;

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;
      if (!_mapController.isCompleted) return;
      if (_lastAnimatedPosition == driverPosition &&
          _lastAnimatedTarget == driverTarget) {
        return;
      }

      _lastAnimatedPosition = driverPosition;
      _lastAnimatedTarget = driverTarget;

      final controller = await _mapController.future;
      final bounds = boundsFromPoints(
        _routePoints.isNotEmpty
            ? _routePoints
            : <ll.LatLng>[driverPosition, if (driverTarget != null) driverTarget],
      );

      if (bounds != null) {
        await controller.animateCamera(
          CameraUpdate.newLatLngBounds(bounds, 80),
        );
      }
    });

    final nextAction = resolveDriverOrderAction(orderStore, activeOrder);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Mapa da entrega'),
      ),
      body: Column(
        children: [
          Expanded(
            child: GoogleMap(
              initialCameraPosition: CameraPosition(
                target: mapCenter.toGMaps(),
                zoom: 14,
              ),
              markers: markers,
              polylines: polylines,
              myLocationEnabled: true,
              myLocationButtonEnabled: true,
              onMapCreated: (controller) {
                if (!_mapController.isCompleted) {
                  _mapController.complete(controller);
                }
              },
            ),
          ),
          Container(
            width: double.infinity,
            color: Colors.white,
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Estado do pedido: ${activeOrder.status.label}',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 4),
                Text(
                  'Ganhos estimados: €${activeOrder.driverEarnings.toStringAsFixed(2)}',
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 12,
                  runSpacing: 8,
                  children: [
                    _InfoChip(
                      icon: Icons.euro,
                      label: 'Pedido',
                      value: '€${activeOrder.total.toStringAsFixed(2)}',
                    ),
                    _InfoChip(
                      icon: Icons.payments,
                      label: 'Ganhos',
                      value:
                          '+€${activeOrder.driverEarnings.toStringAsFixed(2)}',
                    ),
                    _InfoChip(
                      icon: Icons.social_distance,
                      label: 'Distância',
                      value: '${activeOrder.distanceKm.toStringAsFixed(1)} km',
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: activeOrder.destination == null
                      ? null
                      : () => NavigationService.openNavigationOptions(
                            context,
                            activeOrder.destination!,
                          ),
                  icon: const Icon(Icons.navigation),
                  label: const Text('Navegar'),
                ),
                if (activeOrder.pickupAddress != null &&
                    activeOrder.pickupAddress!.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  const Text(
                    'Recolha',
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),
                  Text(activeOrder.pickupAddress!),
                ],
                if (activeOrder.dropoffAddress != null &&
                    activeOrder.dropoffAddress!.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  const Text(
                    'Entrega',
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),
                  Text(activeOrder.dropoffAddress!),
                ],
                if (activeOrder.customerNotes != null &&
                    activeOrder.customerNotes!.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  const Text(
                    'Nota do cliente',
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),
                  Text(activeOrder.customerNotes!),
                ],
                if (activeOrder.apartmentDelivery) ...[
                  const SizedBox(height: 12),
                  const _ApartmentDeliveryBanner(),
                ],
                if (nextAction != null) ...[
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () async {
                        final success = await nextAction.execute();
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                              success
                                  ? nextAction.successMessage
                                  : 'Não foi possível atualizar o pedido.',
                            ),
                          ),
                        );
                      },
                      child: Text(nextAction.label),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _updateRoute(ll.LatLng origin, ll.LatLng destination) {
    final key =
        '${origin.latitude.toStringAsFixed(5)},${origin.longitude.toStringAsFixed(5)}|${destination.latitude.toStringAsFixed(5)},${destination.longitude.toStringAsFixed(5)}';
    if (_activeRouteKey == key && _routePoints.isNotEmpty) {
      return;
    }

    _activeRouteKey = key;
    final requestId = ++_routeRequestId;

    _directionsService
        .fetchRoute(origin: origin, destination: destination)
        .then((route) {
      if (!mounted || _routeRequestId != requestId) {
        return;
      }
      setState(() {
        if (route != null && route.points.isNotEmpty) {
          _routePoints = route.points;
        } else {
          _routePoints = <ll.LatLng>[origin, destination];
        }
      });
    });
  }
}

class _ApartmentDeliveryBanner extends StatelessWidget {
  const _ApartmentDeliveryBanner();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final iconColor = Colors.orange.shade600;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.orange.shade50,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.orange.shade200),
      ),
      child: Row(
        children: [
          Icon(Icons.apartment, color: iconColor),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              'Apartment delivery requested — +€1 bonus',
              style: theme.textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.w600,
                color: Colors.orange.shade800,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _InfoChip extends StatelessWidget {
  const _InfoChip({
    required this.icon,
    required this.label,
    required this.value,
  });

  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.grey.shade200,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: Colors.grey.shade800),
          const SizedBox(width: 6),
          Text(
            '$label: $value',
            style: const TextStyle(fontSize: 12),
          ),
        ],
      ),
    );
  }
}
