import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'auth/auth_store.dart';
import 'dispatch/dispatch_engine.dart';
import 'screens/client_login_screen.dart';
import 'screens/client_main_screen.dart';
import 'screens/driver_home_screen.dart';
import 'screens/driver_login_screen.dart';
import 'screens/login_screen.dart';
import 'screens/partner_entry_screen.dart';
import 'screens/register_client_screen.dart';
import 'screens/register_driver_screen.dart';
import 'screens/role_screen.dart';
import 'stores/cart_store.dart';
import 'stores/driver_store.dart';
import 'stores/order_store.dart';
import 'stores/partner_product_store.dart';
import 'stores/restaurant_store.dart';
import 'stores/session_store.dart';

const String _supabaseUrl = 'https://ojykpzwqrtusfeakzrna.supabase.co';
const String _supabaseAnonKey =
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9qeWtwendxcnR1c2ZlYWt6cm5hIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzMwMDA3MjgsImV4cCI6MjA4ODU3NjcyOH0.-yrhHFZV4bfjBagI5W-c1AvmP8Xkzs1kf2xuxPwdBh4';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: _supabaseUrl,
    anonKey: _supabaseAnonKey,
  );

  if (!kIsWeb) {
    Stripe.publishableKey =
        'pk_test_51T8MG0GmiUUEIr722bf8w8H8LWZgAlMMuPgEP4XOxzfYr9VsiIhxQixvj7uqkdtbfXatRHrvOcgX3C3dv257rjs600mn6d5mVv';
  }

  final sessionStore = SessionStore();
  await sessionStore.load();

  Provider.debugCheckInvalidValueType = null;

  runApp(MyApp(sessionStore: sessionStore));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key, required this.sessionStore});

  final SessionStore sessionStore;

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<SessionStore>.value(value: sessionStore),

        ChangeNotifierProvider<AuthStore>(
          create: (_) => AuthStore(),
        ),

        ChangeNotifierProvider<CartStore>(
          create: (_) => CartStore(),
        ),

        ChangeNotifierProvider<DriverStore>(
          create: (_) => DriverStore(),
        ),

        // RestaurantStore constructor already calls
        // loadRestaurantsFromSupabase() and loadProductsFromSupabase()
        // internally, so no extra calls are needed here.
        ChangeNotifierProvider<RestaurantStore>(
          create: (_) => RestaurantStore(),
        ),

        ChangeNotifierProxyProvider<RestaurantStore, PartnerProductStore>(
          create: (_) => PartnerProductStore(),
          update: (_, RestaurantStore restaurantStore,
              PartnerProductStore? partnerProductStore) {
            partnerProductStore ??= PartnerProductStore();
            partnerProductStore.updateRestaurantStore(restaurantStore);
            return partnerProductStore;
          },
        ),

        ChangeNotifierProxyProvider2<DriverStore, RestaurantStore, OrderStore>(
          create: (context) => OrderStore(
            driverStore: context.read<DriverStore>(),
          ),
          update: (_, DriverStore driverStore, RestaurantStore restaurantStore,
              OrderStore? orderStore) {
            orderStore ??= OrderStore(driverStore: driverStore);
            orderStore.updateDriverStore(driverStore);
            orderStore.updateRestaurantStore(restaurantStore);
            return orderStore;
          },
        ),

        ProxyProvider2<DriverStore, OrderStore, DispatchEngine>(
          create: (_) => DispatchEngine(),
          update: (_, DriverStore driverStore, OrderStore orderStore,
              DispatchEngine? engine) {
            engine ??= DispatchEngine();
            engine.attach(
              orderStore: orderStore,
              driverStore: driverStore,
            );
            orderStore.updateDispatchEngine(engine);
            return engine;
          },
          dispose: (_, DispatchEngine engine) => engine.dispose(),
        ),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'BORA APP',
        theme: ThemeData(primarySwatch: Colors.green),
        routes: {
          '/role': (_) => const RoleScreen(),
          '/login': (_) => const LoginScreen(),
        },
        home: const _RootNavigator(),
      ),
    );
  }
}

class _RootNavigator extends StatelessWidget {
  const _RootNavigator();

  @override
  Widget build(BuildContext context) {
    final session = context.watch<SessionStore>();
    final auth = context.watch<AuthStore>();

    if (!session.isInitialized) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    switch (session.role) {
      case UserRole.client:
        if (auth.currentClient != null) {
          return const ClientMainScreen();
        }
        return auth.hasClientAccounts
            ? const ClientLoginScreen()
            : const RegisterClientScreen();

      case UserRole.driver:
        if (auth.currentDriver != null) {
          return const DriverHomeScreen();
        }
        return auth.hasDriverAccounts
            ? const DriverLoginScreen()
            : const RegisterDriverScreen();

      case UserRole.partner:
        return const PartnerEntryScreen();

      default:
        return const RoleScreen();
    }
  }
}