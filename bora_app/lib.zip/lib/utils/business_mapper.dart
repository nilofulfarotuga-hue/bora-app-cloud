import '../data/fake_data.dart';
import '../models/restaurant_model.dart';
import '../stores/restaurant_store.dart';

class BusinessMapper {
  const BusinessMapper._();

  static Restaurant buildRestaurantMenu({
    required RestaurantStore restaurantStore,
    required RestaurantModel business,
  }) {
    final partnerProducts = restaurantStore.partnerProductsForRestaurant(
      business.id,
      onlyAvailable: true,
    );

    final partnerMenu = partnerProducts
        .map(
          (product) => MenuItem(
            name: product.name,
            price: product.price,
          ),
        )
        .toList();

    final fallback = _findFallbackRestaurant(business.name);

    if (!business.isPartner) {
      return fallback ??
          Restaurant(
            name: business.name,
            isPartner: false,
            menu: partnerMenu,
          );
    }

    if (partnerMenu.isNotEmpty) {
      return Restaurant(
        name: business.name,
        isPartner: true,
        menu: partnerMenu,
      );
    }

    if (fallback != null) {
      return Restaurant(
        name: fallback.name,
        isPartner: true,
        menu: fallback.menu,
      );
    }

    return Restaurant(
      name: business.name,
      isPartner: true,
      menu: const [],
    );
  }

  static RetailStore? buildRetailStore({
    required RestaurantStore restaurantStore,
    required RestaurantModel business,
  }) {
    final partnerProducts = restaurantStore.partnerProductsForRestaurant(
      business.id,
      onlyAvailable: true,
    );

    if (partnerProducts.isNotEmpty) {
      return RetailStore(
        name: business.name,
        isPartner: business.isPartner,
        category: _mapStoreCategory(business.category),
        products: partnerProducts
            .map(
              (product) => MarketProduct(
                name: product.name,
                price: product.price,
              ),
            )
            .toList(),
      );
    }

    final fallback = fakeStoreLookup[business.name];
    if (fallback != null) {
      return RetailStore(
        name: fallback.name,
        isPartner: business.isPartner || fallback.isPartner,
        category: fallback.category,
        products: fallback.products,
      );
    }

    if (business.category == BusinessCategory.restaurant) {
      return null;
    }

    return RetailStore(
      name: business.name,
      isPartner: business.isPartner,
      category: _mapStoreCategory(business.category),
      products: const [],
    );
  }

  static Restaurant? _findFallbackRestaurant(String name) {
    final normalized = name.toLowerCase().trim();
    for (final restaurant in fakeRestaurants) {
      if (restaurant.name.toLowerCase() == normalized) {
        return restaurant;
      }
    }
    return null;
  }

  static StoreCategory _mapStoreCategory(BusinessCategory category) {
    switch (category) {
      case BusinessCategory.pharmacy:
        return StoreCategory.pharmacy;
      case BusinessCategory.restaurant:
      case BusinessCategory.supermarket:
      case BusinessCategory.store:
        return StoreCategory.market;
    }
  }
}
