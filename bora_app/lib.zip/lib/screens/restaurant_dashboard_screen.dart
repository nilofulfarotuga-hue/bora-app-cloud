import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../auth/auth_store.dart';
import '../models/order_model.dart';
import '../models/restaurant_model.dart';
import 'partner_call_driver_screen.dart';
import 'partner_products_screen.dart';
import 'register_partner_screen.dart';
import '../stores/order_store.dart';
import '../stores/restaurant_store.dart';
import '../stores/session_store.dart';

class RestaurantDashboardScreen extends StatelessWidget {
  const RestaurantDashboardScreen({super.key, this.partnerRestaurant});

  final RestaurantModel? partnerRestaurant;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final switchModeColor =
        theme.appBarTheme.foregroundColor ?? theme.colorScheme.onPrimary;
    final restaurantStore = context.watch<RestaurantStore>();
    final authStore = context.watch<AuthStore>();
    final sessionRole = context.watch<SessionStore>().role;
    final isPartnerSession =
        sessionRole == UserRole.partner || authStore.role == AuthRole.partner;
    final isPartnerContext = partnerRestaurant != null || isPartnerSession;

    final restaurants = () {
      if (partnerRestaurant != null) {
        final refreshed =
            restaurantStore.restaurantByEmail(partnerRestaurant!.email);
        if (refreshed != null) {
          return <RestaurantModel>[refreshed];
        }
        return <RestaurantModel>[partnerRestaurant!];
      }

      if (isPartnerSession) {
        final partner = authStore.currentPartner;
        if (partner == null) return <RestaurantModel>[];
        final restaurant = restaurantStore.restaurantByEmail(partner.email);
        if (restaurant == null) {
          return <RestaurantModel>[];
        }
        return <RestaurantModel>[restaurant];
      }

      return restaurantStore.restaurants;
    }();

    if (restaurants.isEmpty) {
      return Scaffold(
        appBar: AppBar(
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new_rounded),
            onPressed: () {
              Navigator.of(context).pushNamedAndRemoveUntil('/', (route) => false);
            },
            tooltip: 'Voltar',
          ),
          title: const Text('Painel do Parceiro'),
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.store_mall_directory_outlined, size: 64, color: Colors.grey),
                const SizedBox(height: 16),
                Text(
                  isPartnerContext
                      ? 'Complete o registo do seu restaurante para aceder ao painel.'
                      : 'Nenhum restaurante disponível no momento.\nAdicione parceiros através da consola interna.',
                  textAlign: TextAlign.center,
                  style: theme.textTheme.bodyLarge?.copyWith(
                    color: Colors.grey.shade700,
                  ),
                ),
                if (isPartnerContext) ...[
                  const SizedBox(height: 24),
                  ElevatedButton.icon(
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => const RegisterPartnerScreen(),
                        ),
                      );
                    },
                    icon: const Icon(Icons.store_mall_directory_outlined),
                    label: const Text('Registar restaurante'),
                  ),
                ],
              ],
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded),
          onPressed: () {
            Navigator.of(context).pushNamedAndRemoveUntil('/', (route) => false);
          },
          tooltip: 'Voltar',
        ),
        title: const Text('Painel do Parceiro'),
        actions: [
          TextButton.icon(
            onPressed: () async {
              final navigator = Navigator.of(context);
              final authStore = context.read<AuthStore>();
              final sessionStore = context.read<SessionStore>();
              authStore.logout();
              await sessionStore.clearRole();
              if (!navigator.mounted) return;
              navigator.pushNamedAndRemoveUntil('/', (route) => false);
            },
            style: TextButton.styleFrom(
              foregroundColor: switchModeColor,
              padding: const EdgeInsets.symmetric(horizontal: 12),
            ),
            icon: Icon(Icons.swap_horiz, color: switchModeColor),
            label: const Text('Switch Mode'),
          ),
        ],
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: restaurants.length,
        itemBuilder: (context, index) {
          final restaurant = restaurants[index];
          final orders = restaurantStore.ordersForRestaurant(restaurant.id);
          return Card(
            margin: const EdgeInsets.only(bottom: 16),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (restaurant.photoUrl.isNotEmpty)
                    ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.network(
                        restaurant.photoUrl,
                        height: 140,
                        width: double.infinity,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                      ),
                    ),
                  if (restaurant.photoUrl.isNotEmpty) const SizedBox(height: 12),
                  Text(
                    restaurant.name,
                    style: theme.textTheme.titleLarge,
                  ),
                  const SizedBox(height: 4),
                  Text(restaurant.address),
                  const SizedBox(height: 4),
                  Text('Categoria: ${restaurant.category.label}'),
                  const SizedBox(height: 4),
                  Text('Telefone: ${restaurant.phone}'),
                  Text('Email: ${restaurant.email}'),
                  Text('Cozinha: ${restaurant.cuisineType}'),
                  const SizedBox(height: 12),
                  if (isPartnerContext)
                    Wrap(
                      spacing: 12,
                      runSpacing: 8,
                      alignment: WrapAlignment.end,
                      children: [
                        ElevatedButton.icon(
                          onPressed: () async {
                            final created = await Navigator.push<bool>(
                              context,
                              MaterialPageRoute(
                                builder: (_) => PartnerCallDriverScreen(restaurant: restaurant),
                              ),
                            );
                            if (!context.mounted || created != true) return;
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('Delivery request submitted. Drivers have been notified.'),
                              ),
                            );
                          },
                          icon: const Icon(Icons.local_shipping_outlined),
                          label: const Text('Call Driver'),
                        ),
                        OutlinedButton.icon(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => PartnerProductsScreen(restaurant: restaurant),
                              ),
                            );
                          },
                          icon: const Icon(Icons.store_mall_directory_outlined),
                          label: const Text('Gerir produtos'),
                        ),
                      ],
                    ),
                                    if (isPartnerContext) const SizedBox(height: 12),
                  if (orders.isEmpty)
                    const Text('Nenhum pedido pendente.'),
                  if (orders.isNotEmpty)
                    ...orders.map((order) => _OrderTile(order: order)),
                  if (isPartnerContext && orders.isNotEmpty) ...[
                    const SizedBox(height: 16),
                    _PartnerEarningsSection(restaurant: restaurant),
                  ],
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class _OrderTile extends StatelessWidget {
  const _OrderTile({required this.order});

  final OrderModel order;

  @override
  Widget build(BuildContext context) {
    final orderStore = context.read<OrderStore>();
    final isCreated = order.status == OrderStatus.created;
    final isPreparing = order.status == OrderStatus.preparing;

    return Container(
      margin: const EdgeInsets.only(top: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey.shade100,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Pedido ${order.id}', style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text('Total: €${order.total.toStringAsFixed(2)}'),
          if (order.customerName != null && order.customerName!.isNotEmpty)
            Text('Cliente: ${order.customerName!}'),
          if (order.clientPhone != null && order.clientPhone!.isNotEmpty)
            Text('Telefone: ${order.clientPhone!}'),
          if (order.dropoffAddress != null && order.dropoffAddress!.isNotEmpty)
            Text('Entrega: ${order.dropoffAddress!}'),
          if (order.customerNotes != null && order.customerNotes!.isNotEmpty)
            Text('Nota: ${order.customerNotes!}'),
          const SizedBox(height: 8),
          Row(
            children: [
              Chip(label: Text(order.status.label)),
              if (isCreated) ...[
                const Spacer(),
                ElevatedButton(
                  onPressed: () {
                    final success = orderStore.restaurantAcceptOrder(order);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          success
                              ? 'Order accepted. Preparation started.'
                              : 'Unable to update the order.',
                        ),
                      ),
                    );
                  },
                  child: const Text('Accept Order'),
                ),
                const SizedBox(width: 8),
                OutlinedButton(
                  onPressed: () {
                    final messenger = ScaffoldMessenger.of(context);
                    showDialog<bool>(
                      context: context,
                      builder: (dialogContext) {
                        return AlertDialog(
                          title: const Text('Reject order?'),
                          content: Text('Are you sure you want to reject order ${order.id}?'),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.of(dialogContext).pop(false),
                              child: const Text('Cancel'),
                            ),
                            ElevatedButton(
                              onPressed: () => Navigator.of(dialogContext).pop(true),
                              child: const Text('Reject Order'),
                            ),
                          ],
                        );
                      },
                    ).then((confirmed) {
                      if (confirmed != true) return;

                      final success = orderStore.restaurantRejectOrder(order);
                      messenger.showSnackBar(
                        SnackBar(
                          content: Text(
                            success
                                ? 'Order rejected.'
                                : 'Unable to reject the order.',
                          ),
                        ),
                      );
                    });
                  },
                  child: const Text('Reject Order'),
                ),
              ],
            ],
          ),
          if (isPreparing) ...[
            const SizedBox(height: 12),
            const _OrderStatusNote(
              icon: Icons.timer,
              message:
                  'Preparação em andamento. Um estafeta será chamado automaticamente em até 5 minutos.',
              color: Colors.orange,
            ),
          ],
          if (order.status == OrderStatus.callingDriver) ...[
            const SizedBox(height: 12),
            const _OrderStatusNote(
              icon: Icons.delivery_dining,
              message: 'Estamos a procurar o melhor estafeta disponível.',
              color: Colors.blue,
            ),
          ],
        ],
      ),
    );
  }
}

class _OrderStatusNote extends StatelessWidget {
  const _OrderStatusNote({
    required this.icon,
    required this.message,
    required this.color,
  });

  final IconData icon;
  final String message;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Icon(icon, color: color),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              message,
              style: theme.textTheme.bodyMedium,
            ),
          ),
        ],
      ),
    );
  }
}

class _PartnerEarningsSection extends StatelessWidget {
  const _PartnerEarningsSection({required this.restaurant});

  final RestaurantModel restaurant;

  static DateTime _startOfDay(DateTime date) {
    final local = date.toLocal();
    return DateTime(local.year, local.month, local.day);
  }

  static bool _isSameDay(DateTime a, DateTime b) {
    final localA = a.toLocal();
    final localB = b.toLocal();
    return localA.year == localB.year &&
        localA.month == localB.month &&
        localA.day == localB.day;
  }

  String _formatCurrency(double value) => '€${value.toStringAsFixed(2)}';

  String _formatDateTime(DateTime dateTime) {
    final local = dateTime.toLocal();
    final day = local.day.toString().padLeft(2, '0');
    final month = local.month.toString().padLeft(2, '0');
    final hour = local.hour.toString().padLeft(2, '0');
    final minute = local.minute.toString().padLeft(2, '0');
    return '$day/$month/${local.year} • $hour:$minute';
  }

  Widget _buildSummaryRow(
    BuildContext context,
    String label,
    String value, {
    bool emphasize = false,
  }) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: theme.textTheme.bodyMedium,
            ),
          ),
          Text(
            value,
            style: theme.textTheme.bodyMedium?.copyWith(
              fontWeight: emphasize ? FontWeight.w600 : FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final orderStore = context.watch<OrderStore>();
    final theme = Theme.of(context);
    final orders = orderStore.partnerOrdersForRestaurant(restaurant.name);

    if (orders.isEmpty) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Earnings', style: theme.textTheme.titleMedium),
          const SizedBox(height: 8),
          const Text('No partner orders yet. Earnings will appear once orders are created.'),
        ],
      );
    }

    final nonRejectedOrders = orders
        .where((order) => order.status != OrderStatus.rejected)
        .toList();

    final today = DateTime.now();
    final todayStart = _startOfDay(today);
    final weekStart = todayStart.subtract(const Duration(days: 6));

    double totalFor(Iterable<OrderModel> items) =>
        items.fold<double>(0, (sum, order) => sum + order.total);
    double commissionFor(Iterable<OrderModel> items) =>
        items.fold<double>(0, (sum, order) => sum + order.platformCommissionAmount);
    double restaurantFor(Iterable<OrderModel> items) =>
        items.fold<double>(0, (sum, order) => sum + order.restaurantEarningsAmount);

    final dailyOrders = nonRejectedOrders
        .where((order) => _isSameDay(order.createdAt, todayStart))
        .toList();
    final dailyCount = dailyOrders.length;
    final dailyTotal = totalFor(dailyOrders);
    final dailyCommission = commissionFor(dailyOrders);
    final dailyRestaurant = restaurantFor(dailyOrders);

    final weeklyOrders = nonRejectedOrders.where((order) {
      final day = _startOfDay(order.createdAt);
      return !day.isBefore(weekStart) && !day.isAfter(todayStart);
    }).toList();
    final weeklyTotal = totalFor(weeklyOrders);
    final weeklyCommission = commissionFor(weeklyOrders);
    final weeklyRestaurant = restaurantFor(weeklyOrders);

    final latestOrders = orders.take(10).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Earnings', style: theme.textTheme.titleMedium),
        const SizedBox(height: 8),
        Card(
          elevation: 0,
          color: Colors.grey.shade50,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Per order',
                  style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 12),
                for (var i = 0; i < latestOrders.length; i++) ...[
                  _buildOrderEntry(context, latestOrders[i]),
                  if (i < latestOrders.length - 1) const Divider(height: 24),
                ],
                if (orders.length > latestOrders.length)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(
                      'Showing latest ${latestOrders.length} of ${orders.length} orders.',
                      style: theme.textTheme.bodySmall?.copyWith(color: Colors.grey.shade600),
                    ),
                  ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        Card(
          elevation: 0,
          color: Colors.grey.shade50,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Daily summary (today)',
                  style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 12),
                _buildSummaryRow(context, 'Orders', '$dailyCount', emphasize: true),
                _buildSummaryRow(context, 'Total sold', _formatCurrency(dailyTotal)),
                _buildSummaryRow(
                  context,
                  'Platform commission (20%)',
                  _formatCurrency(dailyCommission),
                ),
                _buildSummaryRow(
                  context,
                  'Restaurant earnings (80%)',
                  _formatCurrency(dailyRestaurant),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        Card(
          elevation: 0,
          color: Colors.grey.shade50,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Weekly summary (last 7 days)',
                  style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 12),
                _buildSummaryRow(
                  context,
                  'Total sold',
                  _formatCurrency(weeklyTotal),
                ),
                _buildSummaryRow(
                  context,
                  'Platform commission',
                  _formatCurrency(weeklyCommission),
                ),
                _buildSummaryRow(
                  context,
                  'Amount to receive',
                  _formatCurrency(weeklyRestaurant),
                  emphasize: true,
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'Only non-rejected partner restaurant orders are counted towards earnings.',
          style: theme.textTheme.bodySmall?.copyWith(color: Colors.grey.shade600),
        ),
      ],
    );
  }

  Widget _buildOrderEntry(BuildContext context, OrderModel order) {
    final theme = Theme.of(context);
    final isRejected = order.status == OrderStatus.rejected;
    final commission = isRejected ? 0.0 : order.platformCommissionAmount;
    final restaurantShare = isRejected ? 0.0 : order.restaurantEarningsAmount;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Order ${order.id}',
          style: theme.textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 4),
        Text(
          _formatDateTime(order.createdAt),
          style: theme.textTheme.bodySmall?.copyWith(color: Colors.grey.shade600),
        ),
        const SizedBox(height: 8),
        _buildSummaryRow(context, 'Status', order.status.label),
        if (order.customerName != null && order.customerName!.isNotEmpty)
          _buildSummaryRow(context, 'Customer', order.customerName!),
        if (order.clientPhone != null && order.clientPhone!.isNotEmpty)
          _buildSummaryRow(context, 'Phone', order.clientPhone!),
        if (order.dropoffAddress != null && order.dropoffAddress!.isNotEmpty)
          _buildSummaryRow(context, 'Delivery', order.dropoffAddress!),
        _buildSummaryRow(context, 'Order total', _formatCurrency(order.total), emphasize: true),
        _buildSummaryRow(
          context,
          'Platform commission (20%)',
          _formatCurrency(commission),
        ),
        _buildSummaryRow(
          context,
          'Restaurant earnings (80%)',
          _formatCurrency(restaurantShare),
          emphasize: true,
        ),
        if (isRejected)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Text(
              'Rejected orders do not generate payouts.',
              style: theme.textTheme.bodySmall?.copyWith(color: Colors.redAccent),
            ),
          ),
      ],
    );
  }
}
